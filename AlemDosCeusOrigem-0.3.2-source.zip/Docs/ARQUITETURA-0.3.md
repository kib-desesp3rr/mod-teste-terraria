# Base 0.3

- `CultivationState`: progressão, reserva, fluxo, sobrecarga, temporizadores e atributos. Persistência schema 3, com leitura de saves anteriores. Pontos importados são limitados ao total efetivamente conquistado.
- `Cultivator`: ciclo do jogador, efeitos dos atributos, interrupção de meditação, entrada e roteamento dos atalhos registrados.
- `CultivationActions`: fronteira comum para validar e ativar técnicas. Custos são comprometidos após a criação válida do projétil; falhas não consomem Qi. Também centraliza oficina, aprendizagem e configuração voluntária de atalhos vazios.
- `CultivationHud`: inserção antes de Mouse Text, com fallback; não depende de já ter aprendido o método. Barra com estado real dos comandos.
- `CultivationJournal`: quatro abas e ações enfileiradas para a atualização da interface, fora da renderização. Não usa comandos de depuração para dar progresso.
- `OriginWorld`: persistência do altar/guardião e chegada única do mentor. A localização considera terreno sólido e espaço para o NPC.
- Itens e projéteis mantêm seus identificadores anteriores para compatibilidade. Texturas/animadores CC0, manifestações, efeitos e equipamento existentes foram mantidos.
- Diagnósticos permanecem desativados em uso normal. `ORIGEM_TEST=1` habilita verificações do modelo; `ORIGEM_ENGINE=1` habilita a cena efêmera de integração; `ORIGEM_RENDER` habilita pranchas gráficas. Use-os exclusivamente com diretório de saves isolado.

Não há implementação de sincronização do cultivo em rede. Todas as mutações de progressão/custo usadas pelo jogo são restritas ao modo de um jogador. A UI informa essa limitação no multiplayer.
