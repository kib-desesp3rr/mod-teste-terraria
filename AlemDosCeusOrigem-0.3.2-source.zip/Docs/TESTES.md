# Histórico de verificação — Origem 0.1.0

Para esta entrega, leia TESTES-0.2.md. O texto seguinte registra exclusivamente a execução da 0.1.

Data: 19/10/2026. Ambiente: Terraria 1.4.4.9, tModLoader 2026.8.3.0, Windows. Nenhum save pessoal ou mod instalado foi substituído.

## Executado

- Compilação do projeto novo pelo compilador integrado: **0 erros, 0 avisos de C#**. O empacotador emitiu um aviso `Image loading failed: unknown image type`; o pacote foi gerado, os ícones carregaram no cliente e o mod concluiu a carga. O aviso permanece registrado, sem ser ocultado.
- Carga isolada no servidor, chegando ao menu de mundos; carga isolada no cliente gráfico, chegando à conclusão do carregamento de mods.
- `ORIGEM_TEST PASS`: personagem sem método inicia sem Qi; aprendizado explícito/idempotente; gastos exatos; cooldown compartilhado; energia insuficiente sem mutação; sobrecarga; limitação de treino por acertos; desbloqueios; avanço único e seus pré-requisitos; persistência binária de dados e timers; limites de números inválidos; morte; janelas de ataque e defaults de NPCs.
- `ORIGEM_AI PASS`: execução real da AI em cenário controlado com alvo de teste; 59 ticks de antecipação sem contato, transição no tick 60, investida com velocidade/dano, recuperação sem contato e criação efetiva dos três projéteis da salva. Não substitui combate num mundo com terreno.
- `ORIGEM_RECIPES PASS`: as cinco receitas da progressão foram encontradas no registro do jogo.
- `ORIGEM_RENDER PASS`: HUD, sete ícones e quatro silhuetas desenhados na GPU pelo próprio código do mod. A prancha foi inspecionada e uma escala incorreta de primitivas foi corrigida. `Previa-Origem.png` é uma prancha do renderer, **não uma captura de gameplay**.

O teste gráfico revelou também que a consulta de atalhos acontece antes da carga do perfil de input nessa fixture; a prévia foi separada da consulta normal dos controles. A tecla no HUD do jogo continua lendo o atalho configurado.

As verificações são opt-in por `ORIGEM_TEST=1`; a prancha requer `ORIGEM_RENDER` apontando para um PNG. Nenhum desses controles está ativo no uso normal.

## Ainda não certificado

- Ciclo completo em sessão jogada: coletar, fabricar, explorar, combater, avançar e derrotar o guardião.
- Fechar/reabrir arquivos reais de personagem e mundo; foi testada a serialização binária do estado de cultivo, não a campanha inteira.
- Chegada/moradia do orientador no ciclo de cidade e busca da anomalia em terrenos variados.
- Colisões e leitura dos ataques em cenários acidentados, balanceamento Expert/Master, controles alternativos, várias escalas de UI e compatibilidade com outros mods.
- Multiplayer: não implementado; a versão bloqueia suas ações fora de single-player.

Não se declara arte final nem produto completo. O pacote é uma primeira fundação independente, executável pelo tModLoader, com conteúdo e progressão próprios.

## Roteiro de aceitação no jogo

Siga `LEIA-PRIMEIRO.md` usando um personagem de teste. Confira falta de poderes no nascimento; crafting do tratado; Palma com Qi zero; interrupção de meditação; prática sem ganho no ar; sobrecarga por cortes repetidos; bônus/recarga da Guarda; reabrir o personagem com progresso; requisitos e consumo dos cinco jades na pedra; avanço que não se repete; aviso de espaço inválido ao invocar; dois ataques do guardião com tempo de reação; recompensa sem duplicação e flag de vitória persistente.
