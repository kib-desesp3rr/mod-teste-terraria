# Histórico da arte 0.1 — substituído na 0.2

Para os assets ativos desta versão, leia ASSETS-0.2.md e ASSETS_MANIFEST.json. O texto seguinte descreve exclusivamente a versão 0.1.

Nenhum sprite, som, shader ou trecho de código dos mods de referência ou dos protótipos anteriores foi importado.

`Common/Art.cs` desenha ícones, criaturas, orientador, guardião e efeitos com primitivas do runtime. São desenhos originais provisórios, incluídos na licença MIT desta entrega. `icon.png` (80×80) e `icon_small.png` (30×30) foram gerados nesta execução com formas geométricas originais da mesma paleta. Não derivam de um pack externo.

O jogo fornece em tempo de execução o pixel primitivo (`Terraria/Images/MagicPixel`), fontes, iluminação, partículas e sons vanilla referenciados por ID. Esses arquivos do Terraria não são extraídos nem redistribuídos. A licença deste projeto não se estende ao Terraria/tModLoader ou a recursos de seus titulares.

Paleta: tinta escura #131D23; jade #5BE7B8; pergaminho #EADCB7; âmbar #F09148. Silhuetas e formas indicam funções; preparação e recuperação não dependem apenas da cor. Este pacote não alega conter pixel art detalhada final ou shaders cinematográficos.
