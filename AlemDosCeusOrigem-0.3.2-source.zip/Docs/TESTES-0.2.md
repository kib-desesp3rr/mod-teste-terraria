# Verificação real — Origem 0.2.0

19/10/2026. Terraria 1.4.4.9 / tModLoader 2026.8.3.0. Saves pessoais e o mod instalado não foram alterados.

## Executado

- Compilação: **0 erros e 0 avisos de C#**. O empacotador ainda emite `Image loading failed: unknown image type`; gera o pacote e a carga do cliente conclui. O aviso não foi ocultado.
- Cliente gráfico isolado carregou a versão 0.2.0, finalizou conteúdo/receitas e gerou as pranchas pelo pipeline gráfico real.
- Regras: aprendizagem conquistada, gastos exatos, cooldown, energia insuficiente sem mutação, sobrecarga, treino limitado por acertos úteis, desbloqueios, primeiro avanço, persistência binária e rejeição de números inválidos.
- Migração do esquema 1 preserva método aprendido, prática e reino. Fundação depende de vitória efetiva; método do vento aplica o desconto de Qi e o acréscimo de fluxo. Os novos timers são persistidos com limites.
- AI controlada: 60 ticks de antecipação, investida com movimento/dano, recuperação sem contato e criação efetiva de três projéteis.
- **Dez receitas** registradas: progressão original mais armas, passo, elixir e rolo de métodos.
- Renderização GPU: HUD, caderno, 13 ícones, monge, escorpião, morcego, golem e 30 amostras de quadros. As pranchas foram inspecionadas. A primeira tentativa revelou carregamento assíncrono antes da leitura de pixels; foi corrigido com carga imediata na primeira utilização e verificação de textura não vazia.
- 30 PNGs de packs: origem e SHA-256 conferidos; dimensões e quadros registrados no manifesto. PNGs gerados na conversa não estão no pacote.

Os marcadores `ORIGEM_AI`, `ORIGEM_020`, `ORIGEM_TEST`, `ORIGEM_RECIPES` e `ORIGEM_RENDER` terminaram em PASS na carga final. `VERIFICACAO.txt` acompanha a entrega com saída filtrada, sem logs de ambiente.

## Limites

As pranchas são testes do renderer, não capturas de uma campanha jogada. Não foi certificado o ciclo completo de coleta/crafting/exploração/combate nem fechar/reabrir os arquivos reais de personagem e mundo. A serialização binária foi exercitada separadamente. Ainda precisam de testes manuais: moradia do orientador, diferentes terrenos do altar, colisões de armas e passo em cenários acidentados, balanceamento Expert/Master, controles alternativos e compatibilidade com outros mods. Multiplayer não está implementado e as ações próprias continuam limitadas ao modo solo.

Roteiro: conferir personagem sem método; receitas; treino físico até 20; Palma/Corte com energia zero; sobrecarga; três métodos; Guarda sem invulnerabilidade; Passo diante de uma parede; elixir e recarga; avanço com recursos insuficientes; núcleo e vitória para Fundação; salvar/reabrir; boss com leitura clara dos dois ataques; drops e animações de morte sem dano residual.
