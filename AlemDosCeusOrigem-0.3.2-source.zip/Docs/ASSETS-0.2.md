# Arte pronta da versão 0.2

Nenhuma das seis folhas geradas nesta conversa foi incluída no mod. Ficaram como reserva no material de trabalho, seguindo a preferência pelos packs prontos.

Fontes usadas:

- [Dark Fantasy Pixel Pack](https://willyee.itch.io/dark-fantasy-pixel-pack-54-characters-25-monsters-455-weapons), **willYEE**, CC0 1.0: somente golem, escorpião e morcego, com folhas de repouso, locomoção, ataque, dano e morte conforme a disponibilidade de cada personagem. O autor declara geração por IA seguida de tratamento/alinhamento. O ZIP completo fica fora da distribuição.
- [Xianxia Pixel Pack](https://willyee.itch.io/xianxia-pixel-pack), **willYEE**, CC0 1.0: monge em repouso, caminhada e gesto; altar animado. Licença e metadados locais conferidos com a página atual. Também declara assistência de IA.
- [496 pixel art icons](https://opengameart.org/content/496-pixel-art-icons-for-medievalfantasy-rpg), **Henrique Lazarini / 7Soul1**, compilação de **gnola14**, CC0 declarado na compilação revisada: 13 ícones selecionados. Não foram usadas versões antigas, que a página informa conter derivados incompatíveis com domínio público.

São 17 folhas e 145 quadros de origem, além de 13 ícones. A quantidade inclui quadros retimados/interpolados pelo autor; não se afirma que sejam todos desenhos manuais distintos. `ReadyArt.cs` registra dimensões, contagens, velocidades e âncoras. `ASSETS_MANIFEST.json` registra origem e SHA-256 por arquivo; os PNGs são cópias exatas dos packs. Normalização de alpha, escala, tintura e espelhamento acontecem em memória. O escorpião recebe tintura jade; a arte não altera hitboxes.

Licença completa em `ThirdParty/CC0-1.0.txt`. Os créditos e avisos permanecem no `.tmod`; o inventário detalhado acompanha as fontes. Não foi incorporado código ou arte dos mods de referência. A licença MIT do código original não substitui as licenças dos assets. Sons, fontes e primitivas vanilla são referenciados pela instalação legítima, sem extração.
