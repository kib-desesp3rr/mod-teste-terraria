# Além dos Céus — Origem 0.3.1

Correção do HUD, das âncoras dos personagens e das animações de combate. Terraria 1.4.4.9 / tModLoader 2026.8.3.0. Cultivo em um jogador.

## Para usar

Feche o tModLoader antes de trocar o arquivo do mod. Instale `AlemDosCeusOrigem.tmod` pela pasta Mods do tModLoader ou execute `Instalar.cmd` após extrair este pacote. A instalação feita nesta máquina mantém uma cópia do arquivo anterior.

Entre em um mundo local e confira **ORIGEM 0.3.1** no HUD. Seus personagens, mundos e teclas configuradas continuam sendo usados. No perfil encontrado nesta máquina, **J** abre o caderno e **H** medita.

O botão do HUD abre o caderno. Na Jornada, **Ativar atalhos vazios** configura somente comandos sem tecla: Z = Palma, X = Corte, G = Guarda, N = Passo. Mantenha os manuais correspondentes no inventário. Teclas já escolhidas são preservadas.

O início continua exigindo 10 madeiras e uma estrela caída perto de uma bancada para aprender o método. A Palma custa 8 madeiras na Oficina. A barra de técnicas e os botões Usar executam o golpe para a frente; pelos atalhos ou pelo manual você mira com o mouse.

## Corrigido

- **Escala e cliques:** removida a segunda divisão da escala do mouse/tela dentro da camada UI, que já é transformada pelo Terraria. O clique agora possui seu próprio estado de pressionamento, capturado na atualização; não depende de `mouseLeftRelease` continuar disponível após outras interfaces.
- **Menu:** o caderno recebe os cliques antes do HUD que fica atrás dele. Abrir o caderno pelo atalho fecha o inventário para que o menu apareça; abrir o inventário fecha o caderno. O uso da arma é bloqueado enquanto o caderno está aberto, evitando ataques ao clicar nos botões.
- **Mentor:** origem horizontal espelhada corretamente ao virar; não usa a animação de conjuração como conversa. Caminhada e repouso têm relógio próprio, reiniciado na troca de estado.
- **Monstros:** relógios próprios para os estados de voo, repouso e ataque. O escorpião tem preparação, golpe e recuperação delimitados; não repete a animação de ataque durante todo o período de agressividade.
- **Guardião:** animação de dano não recebe o progresso da conjuração. Repouso, movimento e ataque compartilham a referência do chão para evitar deslocamentos verticais ao trocar de folha.
- **Armas:** lâmina e bastão usam a posição da mão e mantêm tamanho constante. A estocada desloca o bastão em vez de esticar seu desenho. A direção é mantida durante o golpe, evitando inversão ao cruzar o cursor.
- **Texturas:** as texturas próprias do mod são normalizadas uma única vez e preparadas antes da partida. Isso também atende aos ícones usados pelo desenho padrão do Terraria ao segurar itens e mostrar cabeças no mapa, que não passam pelos nossos desenhadores. Nenhuma textura do Terraria ou de outros mods é alterada.

As imagens originais e suas licenças foram preservadas. A visualização inicial de algumas folhas aparentava um fundo branco; a comparação com a renderização confirmou que esse fundo já era transparente. A correção final não aplica remoção de fundo branco nem troca os sprites por outros packs.

## Testes

`VERIFICACAO.md` documenta os testes. Foram exercitados cliques pela camada real do jogo em 100%, 110% e 150%, com o sinal de liberação do mouse do Terraria consumido; aprendizagem, oficina, atributos e uso de técnica funcionaram nesse teste. Lâmina e bastão também causaram dano usando o ciclo real de itens/projéteis, tanto para a direita quanto para a esquerda.

São testes de integração em um cliente isolado. Não equivalem a uma campanha completa jogada por uma pessoa e não validam todos os outros mods do perfil. O cultivo segue limitado a um jogador.

## Código e arte

`AlemDosCeusOrigem/` contém a fonte. `Compilar.ps1` recompila usando a instalação local do tModLoader. A migração de save continua em schema 3; esta correção não apaga a progressão.

Arte CC0: willYEE e 7Soul1. Origens, hashes e licenças em `Docs/ASSETS_MANIFEST.json` e `ThirdParty/`. Nenhuma arte de Calamity ou dos outros mods de referência foi adicionada.
