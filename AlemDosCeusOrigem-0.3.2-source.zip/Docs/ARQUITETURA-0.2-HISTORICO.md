# Fundação independente — Origem 0.2

O nome interno é `AlemDosCeusOrigem`. A fundação foi escrita do zero na 0.1 e ampliada na 0.2; não reutiliza o código dos protótipos anteriores chamados AlemDosCeus. A 0.2 mantém os IDs e saves da 0.1. Sprites CC0 prontos foram incorporados conforme ASSETS-0.2.md. A API e o runtime do tModLoader são dependências de plataforma.

Na 0.2: ReadyArt/ReadyClip definem folhas, quadros e âncoras; SpriteBank faz carga/normalização uma única vez por textura no cliente; Effects limita partículas e remanescentes de morte; MartialGear acrescenta armas, passo, elixir e métodos; CultivationJournal apresenta domínio e requisitos. PresentationConfig contém opções visuais. O estado salvo passou ao esquema 2 com leitura dos dados anteriores.

- `Common/CultivationState.cs`: regras de energia, fluxo, sobrecarga, prática, domínio, avanço e serialização versionada. Não depende da interface.
- `Common/Cultivator.cs`: integração da simulação com personagem, inputs, efeitos e acertos observáveis.
- `Common/OriginWorld.cs`: flags do mundo, ponto persistente da anomalia e busca limitada de terreno sem modificar blocos.
- `Content/Items.cs`: itens, receitas e ativação de técnicas, com bloqueio explícito fora de single-player.
- `Content/Techniques.cs`: preparação/janela ativa da palma, onda com colisão e projéteis do guardião.
- `Content/Creatures.cs`: criatura territorial e criatura voadora com antecipação de investida.
- `Content/Guardian.cs`: máquina de estados do guardião, sem dano de contato em preparação/recuperação.
- `Content/Encounters.cs`: NPC orientador, loja e interação de avanço na pedra.
- `Common/Art.cs` e `Common/CultivationHud.cs`: apresentação provisória original e HUD.
- `Diagnostics/`: verificações opt-in de regras, registros e desenho. Não concedem itens ou poder ao jogador normal.

Escopo: modo solo. A lógica de estado foi separada para permitir autoridade do servidor posteriormente; não há um protocolo multiplayer implementado. A versão não deve ser descrita como um mod multiplayer completo.

Save: esquema 1, campos limitados e números não finitos rejeitados. Itens não são concedidos no nascimento. O tratado precisa ser obtido por crafting ou comércio. Não existem poderes hereditários gratuitos, XP global nem escalonamento universal de inimigos.

Próximos marcos: validar o ciclo inteiro em gameplay e arquivos reais de personagem/mundo, refinar leitura visual e balanceamento, produzir pixel art final, implementar protocolo/validação multiplayer e depois expandir métodos e heranças.
