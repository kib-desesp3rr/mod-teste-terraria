using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;

namespace AlemDosCeusOrigem.Common;

public sealed class ReadyClip
{
    public readonly string Name;public readonly int Frames,Width,Height;public readonly float Fps;public readonly Vector2 Foot;
    public ReadyClip(string name,int frames,int width,int height,float fps,float x,float y){Name=name;Frames=frames;Width=width;Height=height;Fps=fps;Foot=new Vector2(x,y);}
    public int Loop()=>(int)((Main.GameUpdateCount%3600000)*Fps/60)%Frames;
    public int At(float ticks,bool repeat=true){int frame=(int)(Math.Max(0,ticks)*Fps/60);return repeat?frame%Frames:Math.Min(Frames-1,frame);}
    public Vector2 Origin(int direction){
        float ground=Name.StartsWith("Guardian")?SpriteBank.Ground("GuardianIdle",10):Name.StartsWith("Scorpion")?SpriteBank.Ground("ScorpionIdle",11):Name.StartsWith("Bat")?SpriteBank.Ground("BatFly",10):Foot.Y;
        return new Vector2(direction<0?Width-Foot.X:Foot.X,ground);
    }
    public int Progress(float progress)=>Math.Clamp((int)(progress*Frames),0,Frames-1);
    public void Draw(SpriteBatch b,Vector2 feet,float canvasHeight,int direction=1,int frame=-1,Color? tint=null){
        if(Main.dedServ)return;var t=SpriteBank.Texture(Name,Frames,1);
        int f=frame<0?Loop():Math.Clamp(frame,0,Frames-1);
        // SpriteEffects flips pixels but does not mirror the origin for an asymmetric sheet.
        Vector2 origin=Origin(direction);
        b.Draw(t,feet,new Rectangle(f*Width,0,Width,Height),tint??Color.White,0,origin,canvasHeight/Height,direction<0?SpriteEffects.FlipHorizontally:SpriteEffects.None,0);
    }
}
