using System;
using System.ComponentModel;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.Config;

namespace AlemDosCeusOrigem.Common;

public sealed class PresentationConfig : ModConfig
{
    public override ConfigScope Mode=>ConfigScope.ClientSide;
    [DefaultValue(128),Range(0,256)] public int ParticleLimit=128;
    [DefaultValue(true)]public bool ReducedFlashes=true;
    [DefaultValue(false)]public bool ScreenShake=false;
}
public sealed class Effects : ModSystem
{
    private struct Spark{public Vector2 At,Speed;public Color Color;public int Life,MaxLife;public float Width;}
    private static readonly Spark[] Sparks=new Spark[256];private static int cursor;private static float shake;
    private struct Remnant{public ReadyClip Clip;public Vector2 Feet;public float Height;public int Direction,Age,Life;}
    private static readonly Remnant[] Remnants=new Remnant[8];private static int remnantIndex;
    public static void Death(ReadyClip clip,Vector2 feet,float height,int direction){if(Main.dedServ)return;Remnants[remnantIndex++%Remnants.Length]=new Remnant{Clip=clip,Feet=feet,Height=height,Direction=direction,Life=(int)(clip.Frames*60/clip.Fps)};}
    public static void Emit(Vector2 at,Vector2 speed,Color color,int life=24,float width=2){
        if(Main.dedServ)return;int limit=ModContent.GetInstance<PresentationConfig>().ParticleLimit;if(limit<=0)return;
        cursor=(cursor+1)%limit;Sparks[cursor]=new Spark{At=at,Speed=speed,Color=color,Life=life,MaxLife=life,Width=width};
    }
    public static void Burst(Vector2 at,Color color,int count=10,float speed=3){
        if(Main.dedServ)return;if(ModContent.GetInstance<PresentationConfig>().ReducedFlashes)count=Math.Min(10,count);for(int i=0;i<count;i++)Emit(at,(i*MathHelper.TwoPi/count).ToRotationVector2()*speed,color,20+i%5,2);
    }
    public static void Shake(float amount){if(!Main.dedServ&&ModContent.GetInstance<PresentationConfig>().ScreenShake)shake=Math.Max(shake,Math.Min(4,amount));}
    public override void ModifyScreenPosition(){if(shake<0.1f)return;Main.screenPosition+=new Vector2((float)Math.Sin(Main.GameUpdateCount*2.1f),(float)Math.Cos(Main.GameUpdateCount*1.8f))*shake;shake*=0.87f;}
    public override void PostUpdateEverything(){for(int i=0;i<Sparks.Length;i++)if(Sparks[i].Life>0){Sparks[i].Life--;Sparks[i].At+=Sparks[i].Speed;Sparks[i].Speed*=0.94f;}for(int i=0;i<Remnants.Length;i++)if(Remnants[i].Life>0){Remnants[i].Life--;Remnants[i].Age++;}}
    public override void PostDrawTiles(){
        if(Main.dedServ||Main.gameMenu)return;
        var b=Main.spriteBatch;b.Begin(SpriteSortMode.Deferred,BlendState.AlphaBlend,SamplerState.PointClamp,null,null,null,Main.GameViewMatrix.TransformationMatrix);
        for(int i=0;i<Sparks.Length;i++){var s=Sparks[i];if(s.Life<=0)continue;float a=s.Life/(float)s.MaxLife;Art.Line(b,s.At-Main.screenPosition,s.At-Main.screenPosition-s.Speed*2,s.Color*a,s.Width*a+0.5f);}
        foreach(var r in Remnants)if(r.Life>0)r.Clip.Draw(b,r.Feet-Main.screenPosition,r.Height,r.Direction,(int)(r.Age*r.Clip.Fps/60),Color.White*Math.Min(1,r.Life/12f));
        b.End();
    }
    public override void OnWorldUnload(){Array.Clear(Sparks);Array.Clear(Remnants);shake=0;cursor=0;remnantIndex=0;}
}
