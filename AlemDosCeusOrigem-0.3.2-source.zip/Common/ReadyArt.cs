namespace AlemDosCeusOrigem.Common;
public static class ReadyArt {
public static readonly ReadyClip GuardianIdle=new ReadyClip("GuardianIdle",10,220,212,7,110,212);
public static readonly ReadyClip GuardianWalk=new ReadyClip("GuardianWalk",10,220,212,8,110,212);
public static readonly ReadyClip GuardianAttack=new ReadyClip("GuardianAttack",10,220,212,11,110,212);
public static readonly ReadyClip GuardianHurt=new ReadyClip("GuardianHurt",5,220,212,12,110,212);
public static readonly ReadyClip GuardianDeath=new ReadyClip("GuardianDeath",10,220,212,9,110,212);
public static readonly ReadyClip ScorpionIdle=new ReadyClip("ScorpionIdle",11,58,74,8,29,74);
public static readonly ReadyClip ScorpionWalk=new ReadyClip("ScorpionWalk",11,58,74,10,29,74);
public static readonly ReadyClip ScorpionAttack=new ReadyClip("ScorpionAttack",11,58,74,14,29,74);
public static readonly ReadyClip ScorpionDeath=new ReadyClip("ScorpionDeath",6,58,74,10,29,74);
public static readonly ReadyClip BatIdle=new ReadyClip("BatIdle",10,44,54,14,22,54);
public static readonly ReadyClip BatFly=new ReadyClip("BatFly",10,44,54,18,22,54);
public static readonly ReadyClip BatAttack=new ReadyClip("BatAttack",10,44,54,15,22,54);
public static readonly ReadyClip BatDeath=new ReadyClip("BatDeath",10,44,54,11,22,54);
public static readonly ReadyClip MentorIdle=new ReadyClip("MentorIdle",2,118,88,8,40,83);
public static readonly ReadyClip MentorWalk=new ReadyClip("MentorWalk",4,118,88,10,40,83);
public static readonly ReadyClip MentorTalk=new ReadyClip("MentorTalk",3,193,82,8,102,82);
public static readonly ReadyClip Node=new ReadyClip("Node",12,256,256,12,128,256);
}
