using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.GameInput;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Common;

public enum CultivationSkill { Palm, Wave, Guard, Step }

// Items, keyboard bindings and UI share the same validation and resource transaction.
public static class CultivationActions
{
    public static readonly int[] Costs={10,18,16,8};
    public static readonly string[] Names={"Palma da Raiz","Corte do Horizonte","Guarda da Montanha","Passo da Névoa"};
    public static bool CanUseManual(Player p,CultivationSkill skill){
        string reason=Blocked(p,skill,true);if(reason==null)return true;
        var c=p.GetModPlayer<Cultivator>();
        if(p.whoAmI==Main.myPlayer&&c.NoticeCooldown==0){Feedback(reason);c.NoticeCooldown=90;}
        return false;
    }
    public static int Manual(CultivationSkill skill)=>skill switch {
        CultivationSkill.Palm=>ModContent.ItemType<RootPalmManual>(),CultivationSkill.Wave=>ModContent.ItemType<HorizonCut>(),
        CultivationSkill.Guard=>ModContent.ItemType<MountainGuard>(),_=>ModContent.ItemType<MistStep>()};
    public static string Blocked(Player p,CultivationSkill skill,bool fromItem=false){
        var s=p.GetModPlayer<Cultivator>().State;
        if(Main.netMode!=NetmodeID.SinglePlayer)return "Esta versão de cultivo exige um jogador.";
        if(p.dead||!p.active)return "Aguarde o renascimento.";
        if(!s.Learned)return "Aprenda a Primeira Respiração na aba Jornada.";
        if(skill==CultivationSkill.Wave&&!s.WaveKnown)return "Requer 20 práticas úteis.";
        if(skill==CultivationSkill.Guard&&!s.GuardKnown)return "Requer 40 práticas úteis.";
        if(skill==CultivationSkill.Step&&s.Realm<1)return "Requer Circulação de Jade.";
        if(!fromItem&&!p.HasItem(Manual(skill)))return "Fabrique o manual na Oficina e mantenha-o no inventário.";
        if(skill==CultivationSkill.Guard&&s.GuardCooldown>0)return $"Guarda recuperando: {Math.Ceiling(s.GuardCooldown/60f)} s.";
        if(skill==CultivationSkill.Step&&s.StepCooldown>0)return "Passo recuperando.";
        if(s.Recovery>0)return "Aguarde a recuperação da técnica.";
        if(!fromItem&&(p.itemAnimation>0||p.mount.Active||p.CCed))return "Termine a ação atual antes de usar uma técnica.";
        if(s.Strain>=70)return "Sobrecarga alta: medite para liberar a circulação.";
        if(!s.CanSpend(Costs[(int)skill]))return $"Qi insuficiente: precisa de {s.EffectiveCost(Costs[(int)skill])}. Use Meditar na Jornada.";
        return null;
    }
    public static bool Activate(Player p,CultivationSkill skill,Vector2 target,bool fromItem=false,int itemDamage=0,IEntitySource source=null){
        string error=Blocked(p,skill,fromItem);
        if(error!=null){Feedback(error);return false;}
        if(p.whoAmI!=Main.myPlayer)return false;
        var c=p.GetModPlayer<Cultivator>();var s=c.State;
        Vector2 aim=(target-p.MountedCenter).SafeNormalize(new Vector2(p.direction,0));
        source??=p.GetSource_Misc("CultivationSkill");
        int cost=Costs[(int)skill],flow=12,recovery=32,entity=-1;
        if(skill==CultivationSkill.Palm||skill==CultivationSkill.Wave){
            bool wave=skill==CultivationSkill.Wave;flow=wave?26:12;recovery=wave?50:32;
            int damage=itemDamage>0?itemDamage:(int)p.GetDamage(DamageClass.Melee).ApplyTo(wave?28:20);
            damage=(int)(damage*(1+(wave?s.WaveMastery:s.PalmMastery)*0.0015f));
            entity=Projectile.NewProjectile(source,p.MountedCenter,aim*(wave?8.5f:0),wave?ModContent.ProjectileType<JadeWave>():ModContent.ProjectileType<RootPalm>(),damage,3,p.whoAmI,aim.ToRotation());
            if(entity<0||entity>=Main.maxProjectiles||!Main.projectile[entity].active){Feedback("Limite de projéteis atingido. Qi preservado.");return false;}
        } else if(skill==CultivationSkill.Guard){flow=16;recovery=30;}
        else {flow=12;recovery=18;}
        if(!s.Spend(cost,flow,recovery)){
            if(entity>=0)Main.projectile[entity].Kill();return false;
        }
        p.direction=aim.X<0?-1:1;c.Meditating=false;
        if(skill==CultivationSkill.Guard){s.GuardTime=180;s.GuardCooldown=480;Effects.Burst(p.Center,Art.Jade,12,2);}
        if(skill==CultivationSkill.Step){p.velocity.X=p.direction*9;s.StepCooldown=90;Effects.Burst(p.Center,Art.Jade,8,2);}
        return true;
    }
    public static void Feedback(string message){CultivationJournal.Message=message;CultivationJournal.MessageTime=240;if(!Main.gameMenu)Main.NewText(message,Art.Parchment);}
    public static void BindEmptyKeys(){
        string[] names={"Journal","Meditate","Palm","Wave","Guard","Step"};string[] keys={"C","V","Z","X","G","N"};int count=0;
        var bindings=PlayerInput.CurrentProfile.InputModes[InputMode.Keyboard].KeyStatus;
        for(int i=0;i<names.Length;i++)if(bindings.TryGetValue("AlemDosCeusOrigem/"+names[i],out var assigned)&&assigned.Count==0){assigned.Add(keys[i]);count++;}
        PlayerInput.Save();Feedback(count+" atalhos vazios configurados. Teclas já escolhidas foram preservadas.");
    }
    public static bool ToggleMeditation(Player p){
        var c=p.GetModPlayer<Cultivator>();
        if(!c.State.Learned){Feedback("Aprenda a Primeira Respiração primeiro.");return false;}
        if(p.dead||Main.netMode!=NetmodeID.SinglePlayer)return false;
        if(!c.Meditating&&(p.velocity.LengthSquared()>0.05f||p.itemAnimation>0||p.mount.Active)){Feedback("Fique parado, sem montar ou atacar, para meditar.");return false;}
        c.Meditating=!c.Meditating;return true;
    }
    public static bool HasWorkbench(Player p){
        Point at=p.Center.ToTileCoordinates();
        for(int x=Math.Max(1,at.X-5);x<=Math.Min(Main.maxTilesX-2,at.X+5);x++)
        for(int y=Math.Max(1,at.Y-4);y<=Math.Min(Main.maxTilesY-2,at.Y+4);y++){
            var t=Main.tile[x,y];if(t.HasTile&&t.TileType==TileID.WorkBenches)return true;
        }
        return false;
    }
    public static int Count(Player p,int type){int count=0;for(int i=0;i<58;i++)if(p.inventory[i].type==type)count+=p.inventory[i].stack;return count;}
    public static bool Pay(Player p,params (int type,int count)[] ingredients){
        foreach(var need in ingredients)if(Count(p,need.type)<need.count){Feedback("Falta: "+need.count+" × "+Lang.GetItemNameValue(need.type)+".");return false;}
        // Inventory is validated in full before any stack changes.
        foreach(var need in ingredients)for(int i=0,left=need.count;i<58&&left>0;i++){
            var item=p.inventory[i];if(item.type!=need.type)continue;int used=Math.Min(item.stack,left);item.stack-=used;left-=used;if(item.stack==0)item.TurnToAir();
        }
        return true;
    }
    public static void Learn(Player p){
        if(Main.netMode!=NetmodeID.SinglePlayer||p.dead)return;
        var s=p.GetModPlayer<Cultivator>().State;if(s.Learned){Feedback("O método já foi aprendido.");return;}
        if(!HasWorkbench(p)){Feedback("Aproxime-se de uma bancada de trabalho.");return;}
        if(!Pay(p,(ItemID.Wood,10),(ItemID.FallenStar,1)))return;
        s.Learn();Feedback("Primeira Respiração aprendida. Fabrique a Palma na Oficina; Meditar recupera Qi.");
    }
    public static void Craft(Player p,int type){
        if(Main.netMode!=NetmodeID.SinglePlayer||p.dead)return;
        // Use the registered recipes, including future ingredient/station changes.
        Recipe recipe=null;
        for(int i=0;i<Recipe.numRecipes;i++)if(Main.recipe[i].createItem.type==type){recipe=Main.recipe[i];break;}
        if(recipe==null)return;
        foreach(int station in recipe.requiredTile){
            if(station<0)break;
            if(station==TileID.WorkBenches&&!HasWorkbench(p)){Feedback("Aproxime-se de uma bancada de trabalho.");return;}
            if(station!=TileID.WorkBenches){Feedback("Este item deve ser fabricado pelo inventário, na estação indicada.");return;}
        }
        var ingredients=new System.Collections.Generic.List<(int,int)>();
        foreach(var item in recipe.requiredItem)if(item.type>0&&item.stack>0)ingredients.Add((item.type,item.stack));
        if(!Pay(p,ingredients.ToArray()))return;
        var product=recipe.createItem.Clone();
        var remainder=p.GetItem(p.whoAmI,product,GetItemSettings.InventoryEntityToPlayerInventorySettings);
        if(!remainder.IsAir)p.QuickSpawnItem(p.GetSource_Misc("CultivationCraft"),remainder,remainder.stack);
        Recipe.FindRecipes();Feedback("Fabricado: "+Lang.GetItemNameValue(type)+".");
    }
}
