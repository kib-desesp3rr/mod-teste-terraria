using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ModLoader;

namespace AlemDosCeusOrigem.Common;

// Keep our click edge in the update cycle. Vanilla UI layers may consume mouseLeftRelease.
public sealed class HudPointer : ModSystem
{
    private static bool wasDown,available;
    public static void Capture(bool down,bool focused=true){available=focused&&down&&!wasDown;wasDown=down;}
    public static bool Take(){if(!available)return false;available=false;return true;}
    public override void PostUpdateInput()=>Capture(Main.mouseLeft,Main.hasFocus);
    public override void OnWorldUnload(){wasDown=false;available=false;}
}
