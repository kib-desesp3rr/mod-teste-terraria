using System;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Terraria;
using Terraria.GameContent;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Common;

public static class CultivationJournal
{
    public static int Tab, MessageTime;
    public static string Message="";
    private static Action pending;
    public static void Update(){
        if(MessageTime>0)MessageTime--;
        var action=pending;pending=null;
        if(!Main.gameMenu&&Main.LocalPlayer.active&&!Main.LocalPlayer.dead)action?.Invoke();
    }
    public static string Key(ModKeybind key,string fallback="—"){
        if(key==null)return fallback;
        try{return key.GetAssignedKeys().FirstOrDefault()??fallback;}
        catch(System.Collections.Generic.KeyNotFoundException){return fallback;}
    }
    public static string Goal(CultivationState s)=>!s.Learned?"Aprenda o método inicial na Jornada.":s.Practice<20?"Acerte criaturas com a Palma: 20 práticas.":s.Practice<40?"Domine o Corte: 40 práticas liberam a Guarda.":s.Practice<80?"Treine até 80 práticas e reúna 5 jades.":s.Realm==0?"Visite o altar: 5 jades, 50 Qi, sobrecarga até 10.":s.Realm==1?"160 práticas + guardião vencido: Fundação Celeste.":"Fundação consolidada. Aperfeiçoe suas técnicas.";
    public static void Draw(){
        var p=Main.LocalPlayer;var s=p.GetModPlayer<Cultivator>().State;var b=Main.spriteBatch;
        float scale=Math.Min(1,Math.Min((Main.screenWidth-16)/680f,(Main.screenHeight-16)/544f));
        Vector2 at=new((Main.screenWidth-680*scale)/2,(Main.screenHeight-544*scale)/2);
        Vector2 mouse=(new Vector2(Main.mouseX,Main.mouseY)-at)/scale;

        Vector2 Pos(float x,float y)=>at+new Vector2(x,y)*scale;
        void Box(float x,float y,float w,float h,Color color)=>Art.Box(b,Pos(x,y),0,0,w*scale,h*scale,color);
        string Fit(string text,float width,float size){while(text.Length>0&&FontAssets.MouseText.Value.MeasureString(text).X*size>width)text=text[..^1];return text;}
        void T(string text,float x,float y,Color color,float size=0.75f,float width=632)=>Utils.DrawBorderString(b,Fit(text,width,size),Pos(x,y),color,size*scale);
        void Wrap(string text,float x,float y,float width,Color color,float size=0.7f){
            string line="";foreach(string word in text.Split(' ')){
                if(FontAssets.MouseText.Value.MeasureString(line+word).X*size>width){T(line,x,y,color,size,width);y+=22;line="";}line+=word+" ";
            }if(line.Length>0)T(line,x,y,color,size,width);
        }
        void Button(string label,float x,float y,float w,Action action,bool enabled=true){
            bool hover=mouse.X>=x&&mouse.X<x+w&&mouse.Y>=y&&mouse.Y<y+30;
            Box(x,y,w,30,!enabled?new Color(42,48,53):hover?new Color(48,98,87):new Color(36,64,63));
            T(label,x+10,y+6,enabled?Art.Parchment:Color.Gray,0.68f,w-16);
            if(enabled&&hover&&pending==null&&HudPointer.Take()){pending=action;}
        }
        Box(0,0,680,544,new Color(16,25,31,248));Box(0,0,680,3,Art.Jade);
        SpriteBank.Icon(b,Pos(32,30),12,30*scale);T("ALÉM DOS CÉUS",58,14,Art.Parchment,1.08f);T("ORIGEM 0.3.1 · BASE DE CULTIVO · UM JOGADOR",58,42,Art.Jade,0.6f);
        Button("Fechar",585,17,76,()=>CultivationHud.JournalOpen=false);
        string[] tabs={"Jornada","Técnicas","Oficina","Atributos"};
        for(int i=0;i<4;i++){int selected=i;Button((Tab==i?"• ":"")+tabs[i],18+i*164,73,154,()=>Tab=selected);}
        Box(18,113,644,1,Art.Jade*0.35f);
        if(Main.netMode!=Terraria.ID.NetmodeID.SinglePlayer){Wrap("Esta versão oferece cultivo apenas em um jogador. Entre em um mundo local para usar as técnicas.",24,136,620,Art.Ember);}
        else if(Tab==0){
            T(s.Learned?(s.Realm==0?"Primeira Respiração":s.Realm==1?"Circulação de Jade":"Fundação Celeste"):"Sua jornada começa aqui",24,129,Art.Jade,0.94f);
            Wrap(Goal(s),24,162,615,Art.Parchment);
            string[] steps={"1. Método: 10 madeiras + 1 estrela caída, perto de uma bancada.","2. Oficina: fabrique a Palma com 8 madeiras; mantenha o manual.","3. Mire com o mouse e use "+Key(OriginMod.Skills[0])+"; acertos reais dão prática.","4. "+Key(OriginMod.Meditate)+": meditar parado. Qi e sobrecarga se recuperam.","5. 20 / 40 práticas: Corte / Guarda. 80: avanço no altar.","6. Guardião + 160 práticas: prepare a Fundação Celeste."};
            for(int i=0;i<steps.Length;i++)T(steps[i],24,220+i*27,Art.Parchment,0.66f);
            Button(s.Learned?"Método aprendido":"Aprender método",24,393,195,()=>CultivationActions.Learn(p),!s.Learned);
            Button("Encontrar mentor",232,393,195,()=>OriginWorld.EnsureMentor(p,true));
            Button("Localizar altar",440,393,195,()=>OriginWorld.LocateNode(p));
            Button(p.GetModPlayer<Cultivator>().Meditating?"Parar meditação":"Meditar",24,438,195,()=>CultivationActions.ToggleMeditation(p),s.Learned);
            Button("Ativar atalhos vazios",232,438,195,CultivationActions.BindEmptyKeys);
            T("Teclas atuais nos botões e na barra.",440,445,Art.Parchment,0.53f,210);
        } else if(Tab==1){
            for(int i=0;i<4;i++){
                int row=i;var skill=(CultivationSkill)i;float y=126+i*86;
                Box(20,y,640,78,new Color(25,39,45));SpriteBank.Icon(b,Pos(49,y+34),new[]{2,3,4,9}[i],32*scale);
                T(CultivationActions.Names[i]+"  ["+Key(OriginMod.Skills[i])+"]",78,y+7,Art.Jade,0.78f,440);
                string[] detail={"Golpe curto · 10 Qi · mire no alvo próximo.","Onda de jade · 18 Qi · até três alvos.","16 Qi · defesa por 3 s · recarga de 8 s.","8 Qi · impulso horizontal · recarga de 1,5 s."};
                T(detail[i],78,y+29,Art.Parchment,0.63f,450);
                T(CultivationActions.Blocked(p,skill)??"Pronta para usar.",78,y+51,Art.Parchment,0.6f,450);
                bool owned=p.HasItem(CultivationActions.Manual(skill));
                Button(owned?"Usar":"Fabricar",548,y+23,99,()=>{if(owned){CultivationHud.JournalOpen=false;CultivationActions.Activate(p,(CultivationSkill)row,p.MountedCenter+new Vector2(p.direction*200,0));}else CultivationActions.Craft(p,CultivationActions.Manual((CultivationSkill)row));});
            }
            T("Mantenha os manuais no inventário. Atalhos: Configurações > Controles.",24,482,Art.Parchment,0.62f);
        } else if(Tab==2){
            int[] types={ModContent.ItemType<RootPalmManual>(),ModContent.ItemType<HorizonCut>(),ModContent.ItemType<MountainGuard>(),ModContent.ItemType<MistStep>(),ModContent.ItemType<SpringStaff>(),ModContent.ItemType<JadeTrainingBlade>(),ModContent.ItemType<HorizonSeal>(),ModContent.ItemType<ThreePaths>()};
            int[] glyphs={2,3,4,9,8,7,5,12};
            string[] costs={"8 madeiras","3 jades + 1 estrela caída","3 jades + 20 pedras","4 jades + 2 penas","18 madeiras","10 madeiras + 2 jades","5 jades + 30 pedras","8 jades + 1 livro"};
            for(int i=0;i<types.Length;i++){
                int type=types[i];float y=122+i*43;SpriteBank.Icon(b,Pos(39,y+17),glyphs[i],24*scale);
                T(Lang.GetItemNameValue(type),62,y+1,Art.Jade,0.65f,350);T(costs[i]+" · bancada",62,y+20,Art.Parchment,0.59f,390);
                Button("Fabricar",538,y+3,112,()=>CultivationActions.Craft(p,type));
            }
            T("Jade: escorpiões de dia e morcegos à noite, fora da vila.",24,474,Art.Parchment,0.62f);
            T("Elixir: jade + água engarrafada + flor do dia, em garrafa (inventário).",24,494,Art.Parchment,0.59f);
        } else {
            T("Pontos disponíveis: "+s.AvailablePoints+"  /  conquistados: "+s.EarnedPoints,24,134,Art.Jade,0.88f);
            T("+1 a cada 20 práticas; +2 por avanço. Limite: 10 em cada atributo.",24,171,Art.Parchment,0.67f);
            string[] names={"Força","Vitalidade","Espírito"};int[] values={s.Strength,s.Vitality,s.Spirit};
            string[] info={"+1% de dano corpo a corpo por ponto.","+5 de vida máxima por ponto.","+3 de Qi máximo por ponto; +1 fluxo a cada 2."};
            for(int i=0;i<3;i++){int stat=i;float y=215+i*72;Box(24,y,626,62,new Color(25,39,45));T(names[i]+"   "+values[i]+" / 10",38,y+7,Art.Jade,0.85f);T(info[i],38,y+35,Art.Parchment,0.65f,450);Button("+ 1",551,y+16,82,()=>{s.Allocate(stat);},s.AvailablePoints>0&&values[i]<10);}
            Button("Redistribuir pontos",24,449,205,()=>{s.Strength=s.Vitality=s.Spirit=0;});
            T("Domínio: Palma "+s.PalmMastery+"/100 · Corte "+s.WaveMastery+"/100",248,457,Art.Parchment,0.65f,400);
        }
        Box(18,517,644,1,Art.Jade*0.35f);
        T(MessageTime>0?Message:"Caderno: "+Key(OriginMod.Journal)+" · Esc fecha · O movimento interrompe a meditação.",24,523,MessageTime>0?Art.Jade:Art.Parchment,0.58f,634);
        if(mouse.X>=0&&mouse.X<=680&&mouse.Y>=0&&mouse.Y<=544){p.mouseInterface=true;p.cursorItemIconEnabled=false;}
        if(Main.keyState.IsKeyDown(Keys.Escape))CultivationHud.JournalOpen=false;
    }
}
