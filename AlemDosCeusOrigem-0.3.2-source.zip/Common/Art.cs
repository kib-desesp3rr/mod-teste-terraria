using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent;

namespace AlemDosCeusOrigem.Common;

// Original code-native placeholder art. No external bitmap or mod artwork is shipped.
public static class Art
{
    public static readonly Color Jade = new(91, 231, 184), Parchment = new(234, 220, 183), Ink = new(19, 29, 35), Ember = new(240, 145, 72);
    public static void Box(SpriteBatch b, Vector2 at, float x, float y, float w, float h, Color c, float scale = 1) => b.Draw(TextureAssets.MagicPixel.Value, at + new Vector2(x,y)*scale, new Rectangle(0,0,1,1), c, 0, Vector2.Zero, new Vector2(w,h)*scale, SpriteEffects.None, 0);
    public static void Line(SpriteBatch b, Vector2 start, Vector2 end, Color c, float width = 2) {
        Vector2 d = end - start;
        b.Draw(TextureAssets.MagicPixel.Value, start, new Rectangle(0,0,1,1), c, d.ToRotation(), new Vector2(0,0.5f), new Vector2(d.Length(),width), SpriteEffects.None,0);
    }
    public static void Ring(SpriteBatch b, Vector2 c, float radius, Color color, int pieces = 24) {
        for(int i=0;i<pieces;i++) Line(b,c+(i*MathHelper.TwoPi/pieces).ToRotationVector2()*radius,c+((i+1)*MathHelper.TwoPi/pieces).ToRotationVector2()*radius,color,2);
    }
    public static void Icon(SpriteBatch b, Vector2 center, int kind, float scale, Color tint) {
        void P(float x,float y,float w,float h,Color c) => Box(b,center,x,y,w,h,new Color(c.ToVector4()*tint.ToVector4()),scale);
        if(kind == 0) { // jade crystal
            P(-4,-12,8,24,Ink); P(-7,-7,14,14,Ink); P(-3,-10,6,20,Jade); P(-5,-5,10,10,Jade); P(-2,-8,2,12,Color.White);
        } else if(kind == 1) { // manual
            P(-11,-13,22,26,Ink); P(-9,-11,18,22,Parchment);P(-8,-11,3,22,new Color(78,108,107));P(-2,-6,8,2,Ink);P(-2,0,8,2,Ink);P(-2,6,6,2,Ink);
        } else if(kind == 2) { // palm
            P(-8,-3,16,15,Jade);for(int i=0;i<4;i++)P(-8+i*4,-12+Math.Abs(i-1)*2,3,12,Jade);P(7,0,5,5,Parchment);P(-4,10,9,4,Ink);
        } else if(kind == 3) { // wave
            for(int i=0;i<12;i++){float a=-1.3f+i*2.6f/12;Line(b,center+new Vector2((float)Math.Cos(a)*12,(float)Math.Sin(a)*12)*scale,center+new Vector2((float)Math.Cos(a+0.22f)*12,(float)Math.Sin(a+0.22f)*12)*scale,new Color(Jade.ToVector4()*tint.ToVector4()),3*scale);}
        } else if(kind == 4) { // guard
            P(-11,-12,22,4,Parchment);P(-9,-8,18,12,Jade);P(-7,4,14,5,Jade);P(-3,9,6,4,Parchment);P(-1,-7,2,15,Ink);
        } else { // stone seal / earned pendant
            P(-10,-10,20,20,Ink); P(-8,-8,16,16,kind==5?Ember:Jade);P(-4,-4,8,8,Ink);P(-1,-6,2,12,Parchment);P(-6,-1,12,2,Parchment);
        }
    }
    public static void Tortoise(SpriteBatch b,Vector2 c,float step,Color color,int direction=1) {
        Box(b,c,-18,-4,36,17,Ink);Box(b,c,-15,-8,28,19,new Color(50,94,79));Box(b,c,-10,-9,18,5,Jade);
        for(int i=0;i<3;i++)Box(b,c,-10+i*8,-2,5,8,color);
        Box(b,c,direction>0?13:-22,-1,9,9,Parchment);Box(b,c,direction>0?19:-21,1,2,2,Ink);
        for(int i=0;i<2;i++)Box(b,c,-12+i*22,11,7,4+(int)(Math.Sin(step+i*3)*2),new Color(121,106,76));
    }
    public static void Moth(SpriteBatch b,Vector2 c,float t) {
        int lift=(int)(Math.Sin(t)*5);
        Box(b,c,-21,-10+lift,15,15,new Color(109,81,109));Box(b,c,6,-10+lift,15,15,new Color(109,81,109));
        Box(b,c,-18,-7+lift,9,9,Ember);Box(b,c,9,-7+lift,9,9,Ember);
        Box(b,c,-5,-7,10,18,Ink);Box(b,c,-3,-5,6,14,Parchment);Box(b,c,-3,-9,2,2,Jade);Box(b,c,1,-9,2,2,Jade);
    }
    public static void Human(SpriteBatch b,Vector2 feet,float walk) {
        Box(b,feet,-10,-35,20,25,Ink);Box(b,feet,-8,-33,16,22,new Color(69,114,109));Box(b,feet,-6,-47,12,13,Parchment);Box(b,feet,-9,-48,18,4,Ink);
        Box(b,feet,-10,-26,20,3,new Color(171,139,84));Box(b,feet,-8,-11,6,10+(int)(Math.Sin(walk)*2),Ink);Box(b,feet,2,-11,6,10-(int)(Math.Sin(walk)*2),Ink);
        Line(b,feet+new Vector2(13,-31),feet+new Vector2(17,0),new Color(160,117,73),3);
    }
    public static void Guardian(SpriteBatch b,Vector2 c,float phase,float step) {
        Box(b,c,-25,-29,50,51,Ink);Box(b,c,-20,-26,40,43,new Color(78,91,104));
        Box(b,c,-29,-20,11,23,new Color(110,120,127));Box(b,c,18,-20,11,23,new Color(110,120,127));
        Box(b,c,-13,-42,26,19,Ink);Box(b,c,-10,-39,20,15,new Color(139,151,153));Box(b,c,-7,-33,14,3,phase>0?Ember:Jade);
        Box(b,c,-6,-18,12,22,phase>0?Ember:Jade);Box(b,c,-3,-14,6,14,Parchment);
        Box(b,c,-19,19,13,16+(int)(Math.Sin(step)*2),Ink);Box(b,c,6,19,13,16-(int)(Math.Sin(step)*2),Ink);
    }
}
