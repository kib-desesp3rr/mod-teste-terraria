namespace AlemDosCeusOrigem.Common;

// Animation advances on entity updates, restarts on state entry, and never depends on draw FPS.
public struct ClipClock
{
    public ReadyClip Clip {get;private set;}
    public float Ticks {get;private set;}
    public int Frame=>Clip?.At(Ticks)??0;
    public void Update(ReadyClip next,float rate=1){
        if(next!=Clip){Clip=next;Ticks=0;}
        else Ticks+=rate;
    }
}
