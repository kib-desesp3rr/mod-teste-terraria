using System;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Common;

public sealed class OriginWorld : ModSystem
{
    public static bool GuardianDefeated, NodeDiscovered;
    public static Vector2 NodeAt;
    private int timer;
    public override void ClearWorld(){GuardianDefeated=false;NodeDiscovered=false;NodeAt=Vector2.Zero;timer=0;}
    public override void SaveWorldData(TagCompound tag){tag["schema"]=1;tag["guardian"]=GuardianDefeated;tag["nodeSeen"]=NodeDiscovered;tag["nodeX"]=NodeAt.X;tag["nodeY"]=NodeAt.Y;}
    public override void LoadWorldData(TagCompound tag){
        GuardianDefeated=tag.GetBool("guardian");NodeDiscovered=tag.GetBool("nodeSeen");
        float x=tag.GetFloat("nodeX"),y=tag.GetFloat("nodeY");
        NodeAt=float.IsFinite(x)&&float.IsFinite(y)&&x>0&&y>0&&x<Main.maxTilesX*16&&y<Main.maxTilesY*16?new Vector2(x,y):Vector2.Zero;
    }
    public static bool TryGround(Vector2 near,int width,int height,out Vector2 feet) {
        feet=Vector2.Zero;
        int startX=(int)near.X/16,startY=(int)near.Y/16;
        for(int dx=0;dx<=12;dx++)for(int side=0;side<(dx==0?1:2);side++){
            int x=startX+dx*(side==0?1:-1);
            if(x<20||x>Main.maxTilesX-20)continue;
            for(int dy=-35;dy<45;dy++){
                int y=startY+dy;if(y<20||y>Main.maxTilesY-20)continue;
                if(!WorldGen.SolidTile(x,y))continue;
                Vector2 bottom=new(x*16+8,y*16);
                if(Collision.SolidCollision(bottom-new Vector2(width/2f,height),width,height))continue;
                if(Main.tile[x,y-1].LiquidAmount>0)continue;
                feet=bottom;return true;
            }
        }
        return false;
    }
    public static bool EnsureMentor(Player p,bool report=false){
        if(Main.netMode!=NetmodeID.SinglePlayer||!p.active||p.dead)return false;
        int type=ModContent.NPCType<Wayfarer>();
        foreach(var npc in Main.npc)if(npc.active&&npc.type==type){if(report)Locate(p,npc.Bottom,"Mentor");return true;}
        Vector2 near=new Vector2(Main.spawnTileX*16+96,Main.spawnTileY*16);
        if(!TryGround(near,22,48,out var feet)&&!TryGround(p.Center+new Vector2(112,0),22,48,out feet)){
            if(report)CultivationActions.Feedback("Não há terreno livre para o mentor. Tente na superfície.");return false;
        }
        int id=NPC.NewNPC(p.GetSource_Misc("WayfarerArrival"),(int)feet.X,(int)feet.Y,type);
        if(id<0||id>=Main.maxNPCs||!Main.npc[id].active)return false;
        Main.npc[id].homeless=true;
        if(report)Locate(p,feet,"Mentor");return true;
    }
    private static void Locate(Player p,Vector2 point,string name){
        int dx=(int)((point.X-p.Center.X)/16),dy=(int)((point.Y-p.Bottom.Y)/16);
        CultivationActions.Feedback($"{name}: {Math.Abs(dx)} blocos à {(dx<0?"esquerda":"direita")}, {Math.Abs(dy)} {(dy<0?"acima":"abaixo")}. Clique com o botão direito para conversar.");
    }
    public static void LocateNode(Player p){
        if(!p.GetModPlayer<Cultivator>().State.Learned){CultivationActions.Feedback("Aprenda o método para sentir o altar.");return;}
        if(NodeAt!=Vector2.Zero){Locate(p,NodeAt,"Altar");return;}
        if(!p.ZoneOverworldHeight||p.ZoneCorrupt||p.ZoneCrimson||p.ZoneJungle||p.ZoneSnow||p.ZoneDesert){CultivationActions.Feedback("Procure uma floresta na superfície para encontrar o altar.");return;}
        if(TryGround(p.Center+new Vector2(p.direction*560,0),32,44,out var feet)){
            int id=NPC.NewNPC(p.GetSource_Misc("StillnessDiscovery"),(int)feet.X,(int)feet.Y,ModContent.NPCType<StillnessNode>());
            if(id<0||id>=Main.maxNPCs||!Main.npc[id].active){CultivationActions.Feedback("Não foi possível manifestar o altar agora.");return;}
            NodeAt=feet;Locate(p,feet,"Altar");
        }else CultivationActions.Feedback("Busque uma área com terreno firme e espaço livre.");
    }
    public override void PostUpdateWorld() {
        if(Main.netMode!=NetmodeID.SinglePlayer||++timer<600)return;
        timer=0;
        Player p=Main.LocalPlayer;
        if(p.active&&!p.dead)EnsureMentor(p);
        if(!p.active||p.dead||!p.GetModPlayer<Cultivator>().State.Learned||NPC.AnyNPCs(ModContent.NPCType<StillnessNode>()))return;
        if(NodeAt!=Vector2.Zero){
            if(Vector2.Distance(p.Center,NodeAt)<1800 && TryGround(NodeAt,32,44,out var restored))NPC.NewNPC(new Terraria.DataStructures.EntitySource_WorldEvent(),(int)restored.X,(int)restored.Y,ModContent.NPCType<StillnessNode>());
            return;
        }
        if(p.ZoneOverworldHeight && !p.ZoneCorrupt && !p.ZoneCrimson && !p.ZoneJungle && !p.ZoneSnow && !p.ZoneDesert && TryGround(p.Center+new Vector2(p.direction*560,0),32,44,out var ground)){
            NodeAt=ground;NPC.NewNPC(new Terraria.DataStructures.EntitySource_WorldEvent(),(int)ground.X,(int)ground.Y,ModContent.NPCType<StillnessNode>());
        }
    }
}
