using Microsoft.Xna.Framework;
using Terraria;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Common;

public sealed class Cultivator : ModPlayer
{
    public CultivationState State = new();
    public bool Meditating;
    public int NoticeCooldown;
    public override void Initialize() { State = new(); Meditating = false; }
    public override void ResetEffects() => State.BonusQi = 0;
    public override void SaveData(TagCompound tag) => tag["cultivation"] = State.Save();
    public override void LoadData(TagCompound tag) => State = tag.TryGet("cultivation", out TagCompound data) ? CultivationState.Restore(data) : new();
    public override void OnEnterWorld() {
        if(Player.whoAmI==Main.myPlayer){CultivationHud.JournalOpen=!State.Learned;CultivationJournal.Tab=0;CultivationJournal.Message="";}
        if (Player.whoAmI == Main.myPlayer && !State.Learned) Main.NewText("Origem 0.3: abra Jornada pelo botão do HUD ou pela tecla "+CultivationJournal.Key(OriginMod.Journal)+". O menu explica como aprender o método.", Art.Parchment);
        if (Player.whoAmI == Main.myPlayer && Main.netMode != NetmodeID.SinglePlayer) Main.NewText(Language.GetTextValue("Mods.AlemDosCeusOrigem.Messages.Solo"), Color.Orange);
    }
    public override void ProcessTriggers(TriggersSet triggersSet) {
        if(Main.drawingPlayerChat||Main.editSign||Main.editChest||Player.talkNPC>=0)return;
        if(OriginMod.Journal.JustPressed)CultivationHud.ToggleJournal();
        if(OriginMod.Meditate.JustPressed)CultivationActions.ToggleMeditation(Player);
        if(Main.playerInventory||CultivationHud.JournalOpen)return;
        for(int i=0;i<4;i++)if(OriginMod.Skills[i].JustPressed)CultivationActions.Activate(Player,(CultivationSkill)i,Main.MouseWorld);
    }
    public override void PostUpdate() {
        if(NoticeCooldown>0)NoticeCooldown--;
        if (Main.netMode != NetmodeID.SinglePlayer) { Meditating = false; return; }
        if (Player.dead || Player.velocity.LengthSquared() > 0.05f || Player.itemAnimation > 0 || Player.mount.Active || Player.grapCount > 0) Meditating = false;
        State.Tick(Meditating, Player.dead);
        if (Meditating && Main.GameUpdateCount % 18 == 0 && !Main.dedServ) {
            var d = Dust.NewDustPerfect(Player.Bottom + new Vector2(Main.rand.Next(-14, 15), -8), DustID.GemEmerald, new Vector2(0, -0.6f), 120, Art.Jade, 0.7f); d.noGravity = true;
        }
    }
    public override void PostUpdateEquips() {
        if(State.Learned&&Main.netMode==NetmodeID.SinglePlayer){Player.statLifeMax2+=State.Vitality*5;Player.GetDamage(DamageClass.Melee)+=State.Strength*0.01f;}
        if (State.GuardTime > 0 && Main.netMode == NetmodeID.SinglePlayer) { Player.statDefense += State.Method==1?12:8; Player.endurance += 0.08f; }
    }
    public override void OnHurt(Player.HurtInfo info) => Meditating = false;
    public override bool PreItemCheck(){if(Player.whoAmI==Main.myPlayer&&CultivationHud.JournalOpen){Player.mouseInterface=true;Player.controlUseItem=false;}return true;}
    public override void UpdateDead() { Meditating = false; State.Qi = 0; State.GuardTime = 0; }
    public override void OnHitNPCWithProj(Projectile proj, NPC target, NPC.HitInfo hit, int damageDone) {
        if (Main.netMode != NetmodeID.SinglePlayer || (proj.ModProjectile is not QiAttack && proj.ModProjectile is not WeaponArc) || target.friendly || target.SpawnedFromStatue || target.lifeMax < 10 || damageDone <= 0) return;
        if(proj.ModProjectile is WeaponArc && State.Practice>=20)return;
        bool wave = proj.type == ModContent.ProjectileType<JadeWave>();
        int old = State.Practice;
        if (State.RecordUsefulHit(wave) && (old == 19 || old == 39 || old == 79)) {
            Main.NewText(Language.GetTextValue("Mods.AlemDosCeusOrigem.Messages.Unlock" + State.Practice), Art.Jade);
        }
    }
}
