using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.Localization;
using Terraria.ModLoader;
using Terraria.UI;

namespace AlemDosCeusOrigem.Common;

public sealed class CultivationHud : ModSystem
{
    public static bool JournalOpen;
    public static void ToggleJournal(){JournalOpen=!JournalOpen;if(JournalOpen){Main.playerInventory=false;Main.LocalPlayer.SetTalkNPC(-1);}}
    private static string L(string key)=>Language.GetTextValue("Mods.AlemDosCeusOrigem.UI."+key);
    public override void OnWorldUnload(){JournalOpen=false;}
    public override void UpdateUI(GameTime gameTime){if(Main.playerInventory)JournalOpen=false;CultivationJournal.Update();}
    public override void ModifyInterfaceLayers(List<GameInterfaceLayer> layers){
        // Mouse Text is stable across resource display styles; always retain a fallback.
        int index=layers.FindIndex(x=>x.Name=="Vanilla: Mouse Text");
        if(index<0)index=layers.Count;
        layers.Insert(index,new LegacyGameInterfaceLayer("Origem: Cultivation",()=>{Draw();return true;},InterfaceScaleType.UI));
    }
    private static void Bar(int x,int y,int w,float fill,Color color){
        var b=Main.spriteBatch;Art.Box(b,Vector2.Zero,x,y,w,7,Art.Ink);Art.Box(b,Vector2.Zero,x+1,y+1,(w-2)*Math.Clamp(fill,0,1),5,color);
    }
    public static void Draw(bool preview=false){
        if(Main.gameMenu||Main.mapFullscreen)return;
        var p=Main.LocalPlayer;var c=p.GetModPlayer<Cultivator>();var s=c.State;
        var b=Main.spriteBatch;
        if(JournalOpen&&!Main.playerInventory){CultivationJournal.Draw();return;}
        if(!Main.playerInventory){
            var at=new Vector2(16,112);
            Art.Box(b,at,0,0,270,128,new Color(19,29,35,230));Art.Box(b,at,0,0,3,128,Art.Jade);
            void Text(string text,float y,Color color,float size=0.7f)=>Utils.DrawBorderString(b,text,at+new Vector2(12,y),color,size);
            Text("ORIGEM 0.3.1 · "+(s.Learned?L(s.Realm==0?"Body":s.Realm==1?"Circulation":"Foundation"):"SEM MÉTODO"),7,Art.Parchment,0.69f);
            Text($"Qi {(int)s.Qi}/{s.MaxQi} · fluxo {s.Flow}",32,Art.Jade);
            Bar(28,165,246,s.MaxQi>0?s.Qi/s.MaxQi:0,Art.Jade);
            Text($"Prática {s.Practice}/{(s.Realm==0?80:160)} · sobrecarga {(int)s.Strain}%",66,s.Strain>=70?Art.Ember:Art.Parchment,0.65f);
            Text(c.Meditating?"MEDITANDO":s.Learned?CultivationJournal.Key(OriginMod.Meditate)+": meditar | "+string.Join(" / ",Array.ConvertAll(OriginMod.Skills,k=>CultivationJournal.Key(k))):"Abra Jornada para começar.",88,Art.Parchment,0.6f);
            var mouse=new Vector2(Main.mouseX,Main.mouseY);
            var button=new Rectangle(28,219,246,20);bool hover=button.Contains(mouse.ToPoint());
            Text("[ "+CultivationJournal.Key(OriginMod.Journal)+" ]  Abrir caderno de cultivo",108,hover?Color.White:Art.Jade,0.62f);
            if(hover){p.mouseInterface=true;if(HudPointer.Take()){ToggleJournal();}}
            if(s.Learned){
                float x=(Main.screenWidth-4*58)/2,y=Main.screenHeight-74;
                for(int i=0;i<4;i++){
                    var skill=(CultivationSkill)i;bool ready=CultivationActions.Blocked(p,skill)==null;
                    Art.Box(b,new Vector2(x+i*58,y),0,0,52,58,new Color(19,29,35,230));
                    SpriteBank.Icon(b,new Vector2(x+i*58+26,y+24),new[]{2,3,4,9}[i],28,ready?Color.White:Color.Gray);
                    string label=CultivationJournal.Key(OriginMod.Skills[i]);int cd=i==2?s.GuardCooldown:i==3?s.StepCooldown:s.Recovery;
                    if(cd>0)label=Math.Ceiling(cd/60f)+"s";
                    Utils.DrawBorderString(b,label,new Vector2(x+i*58+7,y+42),ready?Art.Jade:Art.Parchment,0.58f);
                    if(new Rectangle((int)x+i*58,(int)y,52,58).Contains(mouse.ToPoint())){
                        p.mouseInterface=true;Main.instance.MouseText(CultivationActions.Names[i]+" · "+(CultivationActions.Blocked(p,skill)??"Pronta"));
                        if(HudPointer.Take()){CultivationActions.Activate(p,skill,p.MountedCenter+new Vector2(p.direction*200,0));}
                    }
                }
            }
        }

    }
    public override void PostDrawTiles(){
        if(Main.dedServ||Main.gameMenu||Main.netMode!=Terraria.ID.NetmodeID.SinglePlayer)return;
        var p=Main.LocalPlayer;var s=p.GetModPlayer<Cultivator>().State;
        if(s.GuardTime<=0)return;
        // PostDrawTiles owns no active SpriteBatch; make an isolated world-space batch.
        var b=Main.spriteBatch;
        b.Begin(Microsoft.Xna.Framework.Graphics.SpriteSortMode.Deferred,Microsoft.Xna.Framework.Graphics.BlendState.AlphaBlend,Microsoft.Xna.Framework.Graphics.SamplerState.PointClamp,null,null,null,Main.GameViewMatrix.TransformationMatrix);
        Art.Ring(b,p.Center-Main.screenPosition,31,Art.Jade*0.45f,16);b.End();
    }
}
