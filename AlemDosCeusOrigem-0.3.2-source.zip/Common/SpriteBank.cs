using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ModLoader;
using ReLogic.Content;

namespace AlemDosCeusOrigem.Common;

public sealed class SpriteBank : ModSystem
{
    private sealed class Sheet { public Texture2D Texture; public Rectangle[] Frames; public int MaxHeight, Ground; }
    private static readonly Dictionary<string,Sheet> Sheets=new();
    public static int Loop(int count,int ticks=8)=>(int)(Main.GameUpdateCount/(ulong)ticks)%count;
    public static int Walk(float distance)=>2+(int)(Math.Abs(distance)/7)%4;
    private static Sheet Get(string name,int columns,int rows){
        if(Sheets.TryGetValue(name,out var result))return result;
        var t=ModContent.Request<Texture2D>("AlemDosCeusOrigem/Assets/"+name,AssetRequestMode.ImmediateLoad).Value;
        var data=new Color[t.Width*t.Height];t.GetData(data);
        if(!Array.Exists(data,c=>c.A>32))throw new Exception("Empty texture upload: "+name+" "+t.Width+"x"+t.Height);
        int w=t.Width/columns,h=t.Height/rows;var frames=new Rectangle[columns*rows];int tallest=1,ground=0;
        for(int f=0;f<frames.Length;f++){
            int left=w,top=h,right=-1,bottom=-1,ox=f%columns*w,oy=f/columns*h;
            for(int y=0;y<h;y++)for(int x=0;x<w;x++)if(data[(oy+y)*t.Width+ox+x].A>32){left=Math.Min(left,x);top=Math.Min(top,y);right=Math.Max(right,x);bottom=Math.Max(bottom,y);}
            frames[f]=right<left?new Rectangle(ox,oy,1,1):new Rectangle(ox+left,oy+top,right-left+1,bottom-top+1);
            tallest=Math.Max(tallest,frames[f].Height);
            ground=Math.Max(ground,frames[f].Bottom-oy);
        }
        // Imported PNG sheets use straight alpha. Normalize exactly once, on the rendering thread.
        for(int i=0;i<data.Length;i++){var c=data[i];data[i]=new Color((byte)((c.R*c.A+127)/255),(byte)((c.G*c.A+127)/255),(byte)((c.B*c.A+127)/255),c.A);}
        // These assets belong exclusively to this mod. Normalize their canonical texture too:
        // vanilla held-item and NPC-head drawing uses it without going through our draw helpers.
        // The per-name cache guarantees a single conversion per load; the asset loader owns disposal.
        t.SetData(data);
        result=new Sheet{Texture=t,Frames=frames,MaxHeight=tallest,Ground=ground};Sheets[name]=result;return result;
    }
    public static int Ground(string name,int columns)=>Get(name,columns,1).Ground;
    public static Texture2D Texture(string name,int columns=1,int rows=1)=>Get(name,columns,rows).Texture;
    public override void PostSetupContent(){
        if(Main.dedServ)return;
        Main.QueueMainThreadAction(()=>{
            foreach(var field in typeof(ReadyArt).GetFields(System.Reflection.BindingFlags.Public|System.Reflection.BindingFlags.Static))
                if(field.GetValue(null) is ReadyClip clip)Get(clip.Name,clip.Frames,1);
            for(int i=0;i<=12;i++)Get("Icon"+i,1,1);
        });
    }
    public static void Character(SpriteBatch b,string name,int columns,int rows,int frame,Vector2 feet,float height,int direction=1,Color? tint=null){
        if(Main.dedServ)return;var s=Get(name,columns,rows);var r=s.Frames[Math.Clamp(frame,0,s.Frames.Length-1)];
        b.Draw(s.Texture,feet,r,tint??Color.White,0,new Vector2(r.Width/2f,r.Height),height/s.MaxHeight,direction<0?SpriteEffects.FlipHorizontally:SpriteEffects.None,0);
    }
    public static void Icon(SpriteBatch b,Vector2 center,int index,float size=30,Color? color=null,float rotation=0){
        if(Main.dedServ)return;var s=Get("Icon"+Math.Clamp(index,0,12),1,1);var r=s.Frames[0];
        b.Draw(s.Texture,center,r,color??Color.White,rotation,new Vector2(r.Width/2f,r.Height/2f),size/Math.Max(r.Width,r.Height),SpriteEffects.None,0);
    }
    public static void Weapon(SpriteBatch b,Vector2 hand,int icon,float length,float angle,Color color){
        var s=Get("Icon"+icon,1,1);var r=s.Frames[0];bool staff=icon==8;
        Vector2 grip=staff?new Vector2(r.Width*0.2f,r.Height*0.8f):new Vector2(r.Width*0.22f,r.Height*0.78f);
        b.Draw(s.Texture,hand,r,color,angle+MathHelper.PiOver4,grip,length/(Math.Max(r.Width,r.Height)*0.9f),SpriteEffects.None,0);
    }
    public override void Unload()=>Sheets.Clear();
}

