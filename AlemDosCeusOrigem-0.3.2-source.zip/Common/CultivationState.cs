using System;
using Terraria.ModLoader.IO;

namespace AlemDosCeusOrigem.Common;

// Simulation data is independent of UI, drawing, items and the player's identity.
public sealed class CultivationState
{
    public bool Learned;
    public int Practice, Realm, PalmMastery, WaveMastery, Method;
    public int StepCooldown, ElixirCooldown;
    public float Qi, Strain;
    public int Recovery, GuardTime, GuardCooldown, HitTrainingDelay;
    public int BonusQi;
    public int Strength, Vitality, Spirit;
    public int EarnedPoints => Learned ? Practice / 20 + Realm * 2 : 0;
    public int AvailablePoints => Math.Max(0,EarnedPoints-Strength-Vitality-Spirit);
    public bool Allocate(int stat) {
        if(AvailablePoints<=0)return false;
        if(stat==0&&Strength<10){Strength++;return true;}
        if(stat==1&&Vitality<10){Vitality++;return true;}
        if(stat==2&&Spirit<10){Spirit++;return true;}
        return false;
    }
    public int MaxQi => Learned ? 60 + Realm * 30 + (Realm==2?10:0) + Math.Clamp(BonusQi, 0, 20) + Spirit*3 : 0;
    public int Flow => 16 + Math.Min(4, Practice / 20) * 2 + Realm * 8 + Spirit/2;
    public bool WaveKnown => Learned && Practice >= 20;
    public bool GuardKnown => Learned && Practice >= 40;
    public int EffectiveCost(int cost)=>Method==2?Math.Max(1,(int)Math.Ceiling(cost*0.85f)):cost;
    public int EffectiveFlow(int flow)=>flow+(Method==2?4:0);

    public bool Learn() {
        if (Learned) return false;
        Learned = true; Qi = 20; return true;
    }

    public bool CanSpend(int cost) => Learned && cost > 0 && Recovery == 0 && Strain < 70 && float.IsFinite(Qi) && Qi >= EffectiveCost(cost);
    public bool Spend(int cost, int flow, int recovery) {
        if (!CanSpend(cost) || recovery <= 0 || flow < 0) return false;
        Qi -= EffectiveCost(cost); Recovery = recovery;
        Strain = Math.Clamp(Strain + Math.Max(0, EffectiveFlow(flow) - Flow) * 3, 0, 100);
        return true;
    }

    public bool RecordUsefulHit(bool wave) {
        if (!Learned || HitTrainingDelay > 0) return false;
        HitTrainingDelay = 45;
        Practice = Math.Min(240, Practice + 1);
        if (wave) WaveMastery = Math.Min(100, WaveMastery + 1);
        else PalmMastery = Math.Min(100, PalmMastery + 1);
        return true;
    }

    public bool Advance() {
        if (!Learned || Realm != 0 || Practice < 80 || Strain > 10 || Qi < 50) return false;
        Realm = 1; Qi = MaxQi; return true;
    }
    public bool EstablishFoundation(bool guardianDefeated){
        if(!Learned||Realm!=1||Practice<160||Qi<80||Strain>5||!guardianDefeated)return false;
        Realm=2;Qi=MaxQi;return true;
    }

    public void Tick(bool meditating, bool dead) {
        if (Recovery > 0) Recovery--;
        if (GuardCooldown > 0) GuardCooldown--;
        if (GuardTime > 0) GuardTime--;
        if (HitTrainingDelay > 0) HitTrainingDelay--;
        if(StepCooldown>0)StepCooldown--;
        if(ElixirCooldown>0)ElixirCooldown--;
        Strain = Math.Max(0, Strain - (meditating ? 0.12f : 0.035f));
        if (dead) { Qi = 0; GuardTime = 0; return; }
        if (!float.IsFinite(Qi)) Qi = 0;
        if (Learned && Recovery == 0)
            Qi += (meditating ? 0.24f : 0.065f) * (Strain > 30 ? 0.35f : 1);
        Qi = Math.Clamp(Qi, 0, MaxQi);
    }

    public TagCompound Save() => new TagCompound {
        ["schema"] = 3, ["learned"] = Learned, ["practice"] = Practice, ["realm"] = Realm,
        ["palm"] = PalmMastery, ["wave"] = WaveMastery, ["qi"] = Qi, ["strain"] = Strain,
        ["recovery"] = Recovery, ["guardTime"] = GuardTime, ["guardCooldown"] = GuardCooldown,
        ["method"]=Method,["stepCooldown"]=StepCooldown,["elixirCooldown"]=ElixirCooldown,
        ["strength"]=Strength,["vitality"]=Vitality,["spirit"]=Spirit
    };

    public static CultivationState Restore(TagCompound tag) {
        var s = new CultivationState {
            Learned = tag.GetBool("learned"), Practice = Math.Clamp(tag.GetInt("practice"), 0, 240),
            Realm = Math.Clamp(tag.GetInt("realm"), 0, 2), PalmMastery = Math.Clamp(tag.GetInt("palm"), 0, 100),
            WaveMastery = Math.Clamp(tag.GetInt("wave"), 0, 100), Recovery = Math.Clamp(tag.GetInt("recovery"), 0, 120),
            GuardTime = Math.Clamp(tag.GetInt("guardTime"), 0, 180), GuardCooldown = Math.Clamp(tag.GetInt("guardCooldown"), 0, 480),
            Method=Math.Clamp(tag.GetInt("method"),0,2),StepCooldown=Math.Clamp(tag.GetInt("stepCooldown"),0,120),ElixirCooldown=Math.Clamp(tag.GetInt("elixirCooldown"),0,900)
        };
        // Imported allocations cannot spend more points than the saved progression earned.
        s.Strength=Math.Clamp(tag.GetInt("strength"),0,Math.Min(10,s.EarnedPoints));
        s.Vitality=Math.Clamp(tag.GetInt("vitality"),0,Math.Min(10,s.EarnedPoints-s.Strength));
        s.Spirit=Math.Clamp(tag.GetInt("spirit"),0,Math.Min(10,s.EarnedPoints-s.Strength-s.Vitality));
        float qi = tag.GetFloat("qi"), strain = tag.GetFloat("strain");
        s.Qi = float.IsFinite(qi) ? Math.Clamp(qi, 0, s.MaxQi) : 0;
        s.Strain = float.IsFinite(strain) ? Math.Clamp(strain, 0, 100) : 0;
        if (!s.Learned) { s.Practice = s.Realm = s.PalmMastery = s.WaveMastery = 0; s.Qi = 0; }
        return s;
    }
}
