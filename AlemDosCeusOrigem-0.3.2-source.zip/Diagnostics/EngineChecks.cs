using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
using Terraria.GameInput;
using AlemDosCeusOrigem.Common;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Diagnostics;

// Explicit test-only fixture in the isolated client, before any world is opened.
// Exercises Terraria's ItemCheck and Projectile.Update, rather than calling Shoot/OnHit by hand.
public sealed class EngineChecks : ModSystem
{
    private static void Check(bool ok,string message){if(!ok)throw new Exception(message);}
    private bool pending;
    public override void PostAddRecipes(){
        if(Main.dedServ||Environment.GetEnvironmentVariable("ORIGEM_ENGINE")!="1")return;
        pending=true;
    }
    public override void PostUpdateInput(){if(pending&&Main.gameMenu&&Main.menuMode==0){pending=false;Run();}}
    private void Run(){
        var oldPlayer=Main.player[0];int oldIndex=Main.myPlayer,oldX=Main.maxTilesX,oldY=Main.maxTilesY;
        int oldSpawnX=Main.spawnTileX,oldSpawnY=Main.spawnTileY,oldMouseX=Main.mouseX,oldMouseY=Main.mouseY;
        bool oldMenu=Main.gameMenu,oldInventory=Main.playerInventory;Vector2 oldCamera=Main.screenPosition;int stage=0;
        var npcSnapshot=(NPC[])Main.npc.Clone();var projSnapshot=(Projectile[])Main.projectile.Clone();
        Vector2 nodeAt=OriginWorld.NodeAt;bool guardian=OriginWorld.GuardianDefeated;
        var pressed=new Dictionary<string,bool>(PlayerInput.Triggers.JustPressed.KeyStatus);
        try{
            Main.myPlayer=0;Main.gameMenu=false;Main.maxTilesX=500;Main.maxTilesY=300;Main.spawnTileX=200;Main.spawnTileY=150;
            for(int x=50;x<450;x++)for(int y=110;y<=150;y++){
                var t=Main.tile[x,y];t.ClearEverything();if(y==150){t.HasTile=true;t.TileType=TileID.Stone;}
            }
            for(int i=0;i<Main.maxNPCs;i++)Main.npc[i]=new NPC(){whoAmI=i};
            for(int i=0;i<Main.maxProjectiles;i++)Main.projectile[i]=new Projectile(){whoAmI=i};
            var p=new Player();Main.player[0]=p;p.whoAmI=0;p.active=true;p.dead=false;p.position=new Vector2(3200,2400-p.height);p.direction=1;p.statLife=p.statLifeMax2=100;p.statMana=p.statManaMax2=20;
            var s=p.GetModPlayer<Cultivator>().State;
            Check(CultivationActions.Blocked(p,CultivationSkill.Palm)!=null,"unlearned skill must explain its lock");
            var layers=new List<GameInterfaceLayer>();ModContent.GetInstance<CultivationHud>().ModifyInterfaceLayers(layers);Check(layers.Count==1,"HUD fallback layer missing");
            CultivationActions.Learn(p);Check(!s.Learned,"learning without materials/station changed state");
            var bench=Main.tile[203,149];bench.HasTile=true;bench.TileType=TileID.WorkBenches;
            p.inventory[1]=new Item(ItemID.Wood,10);p.inventory[2]=new Item(ItemID.FallenStar);
            CultivationActions.Learn(p);Check(s.Learned&&CultivationActions.Count(p,ItemID.Wood)==0&&CultivationActions.Count(p,ItemID.FallenStar)==0,"learning did not consume its exact recipe");
            p.inventory[1]=new Item(ItemID.Wood,8);CultivationActions.Craft(p,ModContent.ItemType<RootPalmManual>());
            Check(p.HasItem(ModContent.ItemType<RootPalmManual>())&&CultivationActions.Count(p,ItemID.Wood)==0,"workshop did not put the crafted manual in inventory");
            Check(OriginWorld.EnsureMentor(p)&&OriginWorld.EnsureMentor(p),"mentor spawn failed");
            int mentors=0;foreach(var n in Main.npc)if(n.active&&n.type==ModContent.NPCType<Wayfarer>())mentors++;
            Check(mentors==1,"mentor duplicated");
            stage=1;
            var target=Main.npc[150];target.SetDefaults(NPCID.Zombie);target.whoAmI=150;target.active=true;target.life=target.lifeMax=500;target.defense=0;target.knockBackResist=0;
            target.Center=p.MountedCenter+new Vector2(44,0);
            p.inventory[0]=new Item(ModContent.ItemType<RootPalmManual>());p.selectedItem=0;
            Main.screenPosition=p.MountedCenter-new Vector2(Main.screenWidth/2f,Main.screenHeight/2f);Main.mouseX=Main.screenWidth/2+90;Main.mouseY=Main.screenHeight/2;
            p.releaseUseItem=true;s.Qi=60;s.Recovery=0;bool spawned=false;float qiAfterUse=0;
            for(int tick=0;tick<40;tick++){
                p.controlUseItem=tick==0;p.ItemCheck();
                if(tick==0)qiAfterUse=s.Qi;
                for(int i=0;i<Main.maxProjectiles;i++)if(Main.projectile[i].active){spawned=true;Main.projectile[i].Update(i);}
                s.Tick(false,false);
            }
            Check(spawned,"ItemCheck did not create a palm projectile");
            Check(qiAfterUse==50,"manual use did not spend exactly 10 Qi");
            Check(target.life<500&&s.Practice==1,"real projectile collision did not deal damage and award practice");
            stage=2;
            p.itemAnimation=p.itemTime=0;s.Recovery=0;s.Qi=60;s.Practice=40;s.HitTrainingDelay=0;
            string oldJournal=CultivationJournal.Key(OriginMod.Journal),oldMeditate=CultivationJournal.Key(OriginMod.Meditate);
            CultivationActions.BindEmptyKeys();
            if(oldJournal!="—")Check(CultivationJournal.Key(OriginMod.Journal)==oldJournal,"key setup replaced the journal preference");
            if(oldMeditate!="—")Check(CultivationJournal.Key(OriginMod.Meditate)==oldMeditate,"key setup replaced the meditation preference");
            Check(CultivationJournal.Key(OriginMod.Skills[0])!="—","suggested skill key was not assigned");
            foreach(string key in new[]{"Journal","Meditate","Palm","Wave","Guard","Step"})PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/"+key]=false;
            PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/Journal"]=true;CultivationHud.JournalOpen=false;
            p.GetModPlayer<Cultivator>().ProcessTriggers(PlayerInput.Triggers.Current);Check(CultivationHud.JournalOpen,"journal trigger did not open the menu");
            PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/Journal"]=false;CultivationHud.JournalOpen=false;
            PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/Palm"]=true;
            p.GetModPlayer<Cultivator>().ProcessTriggers(PlayerInput.Triggers.Current);Check(s.Qi==50,"skill trigger did not spend exactly one cost");
            PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/Palm"]=false;s.Qi=60;s.Recovery=0;
            Check(CultivationActions.Activate(p,CultivationSkill.Guard,p.Center,true),"guard activation failed");
            Check(s.Qi==44&&s.GuardTime==180&&s.GuardCooldown==480,"guard cost/timers wrong");
            Check(!CultivationActions.Activate(p,CultivationSkill.Guard,p.Center,true)&&s.Qi==44,"guard cooldown double spent");
            Check(s.AvailablePoints==2&&s.Allocate(1)&&s.Allocate(2)&&!s.Allocate(0),"attribute point budget is not enforced");
            var restored=CultivationState.Restore(s.Save());Check(restored.Vitality==1&&restored.Spirit==1&&restored.AvailablePoints==0,"allocations lost in save");
            p.statLifeMax2=100;p.GetModPlayer<Cultivator>().PostUpdateEquips();Check(p.statLifeMax2==105,"vitality did not change player life");
            var clock=new ClipClock();clock.Update(ReadyArt.MentorWalk);for(int i=0;i<70;i++)clock.Update(ReadyArt.MentorWalk);
            Check(clock.Frame>=0&&clock.Frame<4,"walk frame outside sheet");clock.Update(ReadyArt.MentorIdle);Check(clock.Frame==0,"state transition did not restart animation");
            var copiedClock=clock;copiedClock.Update(ReadyArt.MentorWalk);Check(clock.Clip==ReadyArt.MentorIdle,"cloned NPC changed another entity animation");
            Main.playerInventory=true;CultivationHud.JournalOpen=false;PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/Journal"]=true;
            p.GetModPlayer<Cultivator>().ProcessTriggers(PlayerInput.Triggers.Current);
            Check(CultivationHud.JournalOpen&&!Main.playerInventory,"opening journal from inventory stayed hidden");
            PlayerInput.Triggers.JustPressed.KeyStatus["AlemDosCeusOrigem/Journal"]=false;
            p.controlUseItem=true;p.GetModPlayer<Cultivator>().PreItemCheck();Check(!p.controlUseItem,"modal menu allowed click-through weapon use");CultivationHud.JournalOpen=false;
            // Drive both physical weapon items through ItemCheck, including left-facing swings.
            foreach(int weapon in new[]{ModContent.ItemType<JadeTrainingBlade>(),ModContent.ItemType<SpringStaff>()})foreach(int side in new[]{1,-1}){
                for(int i=0;i<Main.maxProjectiles;i++)Main.projectile[i].active=false;
                p.inventory[0]=new Item(weapon);p.itemAnimation=p.itemTime=0;p.releaseUseItem=true;p.direction=side;
                Main.mouseX=Main.screenWidth/2+side*90;target.Center=p.MountedCenter+new Vector2(side*40,0);target.life=500;target.active=true;Array.Clear(target.immune);bool made=false;
                for(int tick=0;tick<45;tick++){
                    p.controlUseItem=tick==0;p.ItemCheck();
                    for(int i=0;i<Main.maxProjectiles;i++)if(Main.projectile[i].active){made=true;Main.projectile[i].Update(i);Check(float.IsFinite(Main.projectile[i].Center.X),"weapon animation produced invalid position");}
                }
                Check(made&&target.life<500,"physical weapon failed to hit: "+weapon+" facing "+side);
            }
            var scorpion=new NPC();scorpion.SetDefaults(ModContent.NPCType<JadeTortoise>());scorpion.Center=p.Center+new Vector2(40,0);scorpion.ai[0]=420;
            for(int i=0;i<20;i++){scorpion.ModNPC.AI();Check(scorpion.damage==0,"scorpion windup must not cause contact damage");}
            for(int i=0;i<5;i++)scorpion.ModNPC.AI();Check(scorpion.damage==13,"scorpion strike did not become active");
            Mod.Logger.Info("ORIGEM_ANIMATION PASS: state-local clocks reset, frame bounds; ItemCheck blade/staff hit left and right; bounded scorpion windup/strike");
            Mod.Logger.Info("ORIGEM_ENGINE PASS: cold-start HUD fallback; learn/craft exact costs; manual delivered to inventory; unique mentor; ItemCheck -> Shoot -> Projectile.Update -> real NPC damage -> useful practice; keyboard trigger routing and existing preferences; guard/cooldown; attribute budget, persistence and actual life bonus");
        }catch(Exception e){Mod.Logger.Error("ORIGEM_ENGINE FAIL stage="+stage+": "+e);}
        finally{
            for(int x=50;x<450;x++)for(int y=110;y<=150;y++)Main.tile[x,y].ClearEverything();
            Main.npc=npcSnapshot;Main.projectile=projSnapshot;Main.player[0]=oldPlayer;Main.myPlayer=oldIndex;Main.gameMenu=oldMenu;Main.playerInventory=oldInventory;
            Main.maxTilesX=oldX;Main.maxTilesY=oldY;Main.spawnTileX=oldSpawnX;Main.spawnTileY=oldSpawnY;Main.mouseX=oldMouseX;Main.mouseY=oldMouseY;Main.screenPosition=oldCamera;
            OriginWorld.NodeAt=nodeAt;OriginWorld.GuardianDefeated=guardian;CultivationJournal.MessageTime=0;CultivationHud.JournalOpen=false;
            PlayerInput.Triggers.JustPressed.KeyStatus.Clear();foreach(var entry in pressed)PlayerInput.Triggers.JustPressed.KeyStatus[entry.Key]=entry.Value;
        }
    }
}
