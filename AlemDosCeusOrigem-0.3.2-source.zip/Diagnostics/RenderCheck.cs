using System;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Diagnostics;

// Opt-in offscreen renderer preview. This is a presentation board, not a gameplay screenshot.
public sealed class RenderCheck : ModSystem
{
    private string pending;
    public override void PostSetupContent(){
        string output=Environment.GetEnvironmentVariable("ORIGEM_RENDER");
        if(Main.dedServ||string.IsNullOrEmpty(output))return;
        pending=output;
    }
    public override void PostUpdateInput(){
        if(pending==null||!Main.gameMenu||Main.menuMode!=0)return;
        string output=pending;pending=null;
        Main.QueueMainThreadAction(()=>{
            var device=Main.instance.GraphicsDevice;var old=device.GetRenderTargets();
            Player oldPlayer=Main.player[0];int oldIndex=Main.myPlayer;bool oldMenu=Main.gameMenu;
            try {
                Main.myPlayer=0;Main.player[0]=new Player();Main.player[0].active=true;
                var state=Main.player[0].GetModPlayer<Cultivator>().State;state.Learn();state.Practice=40;state.Qi=43;
                using var target=new RenderTarget2D(device,1000,600);device.SetRenderTarget(target);device.Clear(new Color(25,34,43));
                var b=Main.spriteBatch;b.Begin(SpriteSortMode.Deferred,BlendState.AlphaBlend,SamplerState.PointClamp,DepthStencilState.None,RasterizerState.CullNone);
                Utils.DrawBorderString(b,"ALÉM DOS CÉUS",new Vector2(34,25),Art.Parchment,1.4f);
                Utils.DrawBorderString(b,"ORIGEM 0.3  ·  SPRITES PRONTOS CC0",new Vector2(35,65),Art.Jade,0.85f);
                Main.gameMenu=false;CultivationHud.Draw(true);Main.gameMenu=true;
                Art.Box(b,new Vector2(0,0),335,348,630,4,new Color(81,104,99));
                ReadyArt.MentorIdle.Draw(b,new Vector2(405,347),70,1,0);ReadyArt.ScorpionWalk.Draw(b,new Vector2(550,347),65,1,3,new Color(160,235,195));ReadyArt.BatFly.Draw(b,new Vector2(700,330),70,1,2);
                ReadyArt.GuardianIdle.Draw(b,new Vector2(860,347),140,1,0);
                string[] labels={"Andarilho","Escorpião de Jade","Morcego","Guardião"};
                for(int i=0;i<4;i++)Utils.DrawBorderString(b,labels[i],new Vector2(355+i*146,370),Art.Parchment,0.65f);
                for(int i=0;i<13;i++){SpriteBank.Icon(b,new Vector2(350+i*49,460),i,32);}
                Utils.DrawBorderString(b,"Aprender  >  praticar  >  abrir a circulação  >  desafiar o guardião",new Vector2(35,525),Art.Parchment,0.8f);
                Utils.DrawBorderString(b,"Prancha do renderer · willYEE + 7Soul1 / CC0 · não é captura de gameplay",new Vector2(35,565),new Color(167,184,191),0.65f);
                b.End();device.SetRenderTargets(old);
                Directory.CreateDirectory(Path.GetDirectoryName(output));using var stream=File.Create(output);target.SaveAsPng(stream,target.Width,target.Height);
                using(var film=new RenderTarget2D(device,1000,360)){
                    device.SetRenderTarget(film);device.Clear(new Color(25,34,43));b.Begin(SpriteSortMode.Deferred,BlendState.AlphaBlend,SamplerState.PointClamp,DepthStencilState.None,RasterizerState.CullNone);
                    for(int f=0;f<10;f++){ReadyArt.GuardianAttack.Draw(b,new Vector2(50+f*100,145),130,1,f);ReadyArt.ScorpionWalk.Draw(b,new Vector2(50+f*100,240),60,1,f);ReadyArt.BatFly.Draw(b,new Vector2(50+f*100,330),65,1,f);}
                    b.End();device.SetRenderTargets(old);using var filmFile=File.Create(Path.Combine(Path.GetDirectoryName(output),"Quadros-CC0.png"));film.SaveAsPng(filmFile,film.Width,film.Height);
                }
                int oldWidth=Main.screenWidth,oldHeight=Main.screenHeight;float oldScale=Main.UIScale;
                try{
                    Main.screenWidth=1000;Main.screenHeight=650;Main.UIScale=1;
                    for(int tab=0;tab<5;tab++){
                        state.Realm=tab==0?0:1;state.Practice=tab==0?0:120;state.Learned=tab!=0;
                        CultivationJournal.Tab=tab==0?0:tab-1;
                        using var panel=new RenderTarget2D(device,1000,650);device.SetRenderTarget(panel);device.Clear(new Color(25,34,43));b.Begin(SpriteSortMode.Deferred,BlendState.AlphaBlend,SamplerState.PointClamp,DepthStencilState.None,RasterizerState.CullNone);
                        CultivationJournal.Draw();b.End();device.SetRenderTargets(old);using var file=File.Create(Path.Combine(Path.GetDirectoryName(output),"Menu-"+tab+".png"));panel.SaveAsPng(file,panel.Width,panel.Height);
                    }
                }finally{Main.screenWidth=oldWidth;Main.screenHeight=oldHeight;Main.UIScale=oldScale;CultivationJournal.Tab=0;}
                int mx=Main.mouseX,my=Main.mouseY;bool ml=Main.mouseLeft,mr=Main.mouseLeftRelease;
                int sw=Main.screenWidth,sh=Main.screenHeight;float ui=Main.UIScale;
                try{
                    Main.screenWidth=1000;Main.screenHeight=650;Main.UIScale=1;Main.gameMenu=false;
                    using var inputTarget=new RenderTarget2D(device,1000,650);device.SetRenderTarget(inputTarget);
                    CultivationJournal.Tab=0;CultivationHud.JournalOpen=true;
                    Main.mouseX=350;Main.mouseY=139;Main.mouseLeft=true;Main.mouseLeftRelease=true;
                    HudPointer.Capture(false);HudPointer.Capture(true);
                    b.Begin();CultivationJournal.Draw();b.End();CultivationJournal.Update();
                    if(CultivationJournal.Tab!=1)throw new Exception("UI tab mouse click did not navigate");
                    Main.mouseX=760;Main.mouseY=82;Main.mouseLeftRelease=true;
                    HudPointer.Capture(false);HudPointer.Capture(true);
                    b.Begin();CultivationJournal.Draw();b.End();CultivationJournal.Update();
                    if(CultivationHud.JournalOpen)throw new Exception("UI close mouse click failed");
                    device.SetRenderTargets(old);
                }finally{Main.mouseX=mx;Main.mouseY=my;Main.mouseLeft=ml;Main.mouseLeftRelease=mr;Main.screenWidth=sw;Main.screenHeight=sh;Main.UIScale=ui;CultivationJournal.Tab=0;CultivationHud.JournalOpen=false;}
                Mod.Logger.Info("ORIGEM_RENDER PASS: ready CC0 sprites, 13 inventory icons, animation frames, five menu states and real UI mouse routing (tab navigation and close) rendered on GPU");
            }catch(Exception ex){try{Main.spriteBatch.End();}catch{}Mod.Logger.Error("ORIGEM_RENDER FAIL: "+ex.Message);}
            finally{device.SetRenderTargets(old);Main.player[0]=oldPlayer;Main.myPlayer=oldIndex;Main.gameMenu=oldMenu;}
        });
    }
}
