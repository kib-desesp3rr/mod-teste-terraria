using System;
using System.Reflection;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameInput;
using Terraria.ID;
using Terraria.ModLoader;
using Terraria.UI;
using AlemDosCeusOrigem.Common;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Diagnostics;

public sealed class InterfaceChecks : ModSystem
{
    private bool pending;
    private static void Check(bool value,string text){if(!value)throw new Exception(text);}
    public override void PostSetupContent()=>pending=!Main.dedServ&&Environment.GetEnvironmentVariable("ORIGEM_ENGINE")=="1";
    public override void PostUpdateInput(){if(pending&&Main.gameMenu&&Main.menuMode==0){pending=false;Main.QueueMainThreadAction(Run);}}
    private void Run(){
        var oldPlayer=Main.player[0];int oldIndex=Main.myPlayer;bool oldMenu=Main.gameMenu,oldInventory=Main.playerInventory;
        int oldWidth=Main.screenWidth,oldHeight=Main.screenHeight,oldX=Main.maxTilesX,oldY=Main.maxTilesY;
        bool oldLeft=Main.mouseLeft,oldRelease=Main.mouseLeftRelease;float oldScale=Main.UIScale;
        var oldProjectiles=(Projectile[])Main.projectile.Clone();var device=Main.instance.GraphicsDevice;var targets=device.GetRenderTargets();
        string[] fields={"_originalScreenWidth","_originalScreenHeight","_originalMouseX","_originalMouseY"};
        var originals=new object[fields.Length];
        FieldInfo Field(string name)=>typeof(PlayerInput).GetField(name,BindingFlags.Static|BindingFlags.NonPublic);
        for(int i=0;i<fields.Length;i++)originals[i]=Field(fields[i]).GetValue(null);
        try{
            for(int i=0;i<=12;i++){
                var texture=SpriteBank.Texture("Icon"+i);
                Check(ReferenceEquals(texture,ModContent.Request<Texture2D>("AlemDosCeusOrigem/Assets/Icon"+i).Value),"held item asset differs from normalized icon");
                var pixels=new Color[texture.Width*texture.Height];texture.GetData(pixels);
                foreach(var pixel in pixels)Check(pixel.R<=pixel.A&&pixel.G<=pixel.A&&pixel.B<=pixel.A,"held icon has non-premultiplied transparent pixels");
            }
            Main.gameMenu=false;Main.myPlayer=0;Main.playerInventory=false;Main.maxTilesX=500;Main.maxTilesY=300;
            var bench=Main.tile[203,149];bench.HasTile=true;bench.TileType=TileID.WorkBenches;
            using var image=new RenderTarget2D(device,1920,1080);device.SetRenderTarget(image);
            foreach(float uiScale in new[]{1f,1.1f,1.5f}){
                var p=new Player(){active=true,whoAmI=0,position=new Vector2(3200,2358)};Main.player[0]=p;
                var state=p.GetModPlayer<Cultivator>().State;
                Main.screenWidth=1920;Main.screenHeight=1080;
                Field(fields[0]).SetValue(null,1920);Field(fields[1]).SetValue(null,1080);Main.UIScale=uiScale;
                Check(Math.Abs(Main.UIScale-uiScale)<0.001f,"requested scale was clamped by fixture: "+Main.UIScale);
                float w=(int)(1920/uiScale),h=(int)(1080/uiScale);
                float panelScale=Math.Min(1,Math.Min((w-16)/680,(h-16)/544));
                Vector2 at=new((w-680*panelScale)/2,(h-544*panelScale)/2);
                var layer=new LegacyGameInterfaceLayer("Origem: regression",()=>{CultivationHud.Draw();return true;},InterfaceScaleType.UI);
                void Click(Vector2 position,bool newPress=true){
                    Field(fields[2]).SetValue(null,(int)(position.X*uiScale));Field(fields[3]).SetValue(null,(int)(position.Y*uiScale));
                    PlayerInput.SetZoom_Unscaled();Main.mouseLeft=true;
                    // Reproduce vanilla having consumed its release flag before our draw layer.
                    Main.mouseLeftRelease=false;
                    if(newPress)HudPointer.Capture(false);HudPointer.Capture(true);
                    layer.Draw();CultivationJournal.Update();
                }
                void Panel(float x,float y)=>Click(at+new Vector2(x,y)*panelScale);
                CultivationHud.JournalOpen=false;CultivationJournal.Tab=0;
                Click(new Vector2(70,228));Check(CultivationHud.JournalOpen,"HUD open click failed at "+uiScale);
                for(int tab=0;tab<4;tab++){Panel(45+164*tab,84);Check(CultivationJournal.Tab==tab,"tab "+tab+" failed at "+uiScale);}
                Panel(45,84);p.inventory[1]=new Item(ItemID.Wood,10);p.inventory[2]=new Item(ItemID.FallenStar);
                Panel(65,405);Check(state.Learned,"learn button failed at "+uiScale);
                Panel(372,84);p.inventory[1]=new Item(ItemID.Wood,8);
                Panel(565,136);Check(p.HasItem(ModContent.ItemType<RootPalmManual>()),"workshop button failed at "+uiScale);
                Panel(537,84);state.Practice=40;
                Panel(575,313);Check(state.Vitality==1,"attribute button failed at "+uiScale);
                Click(at+new Vector2(575,313)*panelScale,false);Check(state.Vitality==1,"held mouse repeated attribute action at "+uiScale);
                Panel(620,30);Check(!CultivationHud.JournalOpen,"close click failed at "+uiScale);
                state.Qi=60;state.Recovery=0;
                Click(new Vector2((w-232)/2+26,h-50));Check(state.Qi==50,"skill bar click failed at "+uiScale);
                Check(ReadyArt.MentorIdle.Origin(-1).X==ReadyArt.MentorIdle.Width-ReadyArt.MentorIdle.Origin(1).X,"mirrored mentor anchor mismatch");
                Check(ReadyArt.GuardianIdle.Origin(1).Y==ReadyArt.GuardianAttack.Origin(1).Y,"guardian foot height changes on attack");
            }
            Mod.Logger.Info("ORIGEM_UI_SCALE PASS: canonical held-item/head icon transparency; real GameInterfaceLayer.Draw at 100%,110%,150%; consumed vanilla release flag; HUD open, four tabs, learn, craft, allocate, held-click rejection, close and skill-bar cast; mirrored anchors and shared ground");
        }catch(Exception e){Mod.Logger.Error("ORIGEM_UI_SCALE FAIL: "+e);}
        finally{
            device.SetRenderTargets(targets);Main.player[0]=oldPlayer;Main.myPlayer=oldIndex;Main.gameMenu=oldMenu;Main.playerInventory=oldInventory;
            Main.maxTilesX=oldX;Main.maxTilesY=oldY;Main.tile[203,149].ClearEverything();Main.projectile=oldProjectiles;
            Main.UIScale=oldScale;for(int i=0;i<fields.Length;i++)Field(fields[i]).SetValue(null,originals[i]);PlayerInput.SetZoom_Unscaled();
            Main.screenWidth=oldWidth;Main.screenHeight=oldHeight;Main.mouseLeft=oldLeft;Main.mouseLeftRelease=oldRelease;HudPointer.Capture(false);
            CultivationHud.JournalOpen=false;CultivationJournal.Tab=0;CultivationJournal.MessageTime=0;
        }
    }
}
