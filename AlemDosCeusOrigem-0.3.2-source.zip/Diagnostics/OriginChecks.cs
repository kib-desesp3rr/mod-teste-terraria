using System;
using System.IO;
using Terraria;
using Terraria.ModLoader;
using Terraria.ModLoader.IO;
using AlemDosCeusOrigem.Common;
using AlemDosCeusOrigem.Content;

namespace AlemDosCeusOrigem.Diagnostics;

// Opt-in checks run by the isolated build environment. No player files or worlds are touched.
public sealed class OriginChecks : ModSystem
{
    private static void Check(bool condition,string message){if(!condition)throw new Exception("ORIGEM CHECK: "+message);}
    public override void PostSetupContent(){
        if(Environment.GetEnvironmentVariable("ORIGEM_TEST")!="1")return;
        var s=new CultivationState();
        Check(s.MaxQi==0 && !s.CanSpend(10) && !s.Advance(),"new character starts without a method");
        Check(s.Learn() && !s.Learn() && s.Qi==20,"learning is explicit and idempotent");
        Check(!s.WaveKnown && !s.GuardKnown,"techniques gated by practice");
        Check(s.Spend(10,12,32) && s.Qi==10,"exact cost");
        Check(!s.Spend(10,12,32) && s.Qi==10,"shared cooldown cannot double spend");
        for(int i=0;i<32;i++)s.Tick(false,false);
        s.Qi=9;Check(!s.Spend(10,12,32) && s.Qi==9,"insufficient energy does not mutate state");
        s.Qi=60;s.Recovery=0;Check(s.Spend(18,26,50) && s.Strain==30,"meridian overflow produces strain");
        s.Strain=75;s.Recovery=0;Check(!s.Spend(10,12,32),"severe strain blocks techniques");
        s.Strain=0;s.Practice=0;s.HitTrainingDelay=0;
        Check(s.RecordUsefulHit(false)&&!s.RecordUsefulHit(false)&&s.Practice==1,"training throttles repeat hits");
        for(int i=0;i<79;i++){s.HitTrainingDelay=0;s.RecordUsefulHit(i%2==0);}
        Check(s.Practice==80&&s.WaveKnown&&s.GuardKnown,"both earned technique thresholds");
        s.Qi=49;Check(!s.Advance(),"advancement energy requirement");
        s.Qi=60;s.Strain=11;Check(!s.Advance(),"advancement stability requirement");
        s.Strain=0;Check(s.Advance()&&!s.Advance()&&s.MaxQi==90,"one-time realm advancement");
        s.Recovery=21;s.GuardCooldown=390;s.GuardTime=100;
        using(var stream=new MemoryStream()){
            TagIO.ToStream(s.Save(),stream);stream.Position=0;
            var restored=CultivationState.Restore(TagIO.FromStream(stream));
            Check(restored.Learned&&restored.Practice==80&&restored.Realm==1&&restored.Qi==90&&restored.Recovery==21&&restored.GuardCooldown==390,"binary save/load keeps progress and timers");
        }
        var broken=s.Save();broken["qi"]=float.NaN;broken["strain"]=float.PositiveInfinity;broken["practice"]=int.MaxValue;
        var safe=CultivationState.Restore(broken);Check(safe.Qi==0&&safe.Strain==0&&safe.Practice==240,"invalid saved numbers bounded");
        safe.Tick(false,true);Check(safe.Qi==0&&safe.GuardTime==0,"death removes current power and guard");
        Check(!RootPalm.Active(6)&&RootPalm.Active(7)&&RootPalm.Active(13)&&!RootPalm.Active(14),"palm active frames exclude preparation and recovery");
        for(int phase=0;phase<6;phase++)Check(HorizonGuardian.ContactWindow(phase)==(phase==0||phase==2),"boss telegraph contact rules");
        var guardian=new NPC();guardian.SetDefaults(ModContent.NPCType<HorizonGuardian>());
        Check(guardian.lifeMax==1600&&!guardian.noGravity&&!guardian.noTileCollide,"guardian has grounded collision");
        var turtle=new NPC();turtle.SetDefaults(ModContent.NPCType<JadeTortoise>());Check(turtle.damage==0,"territorial creature begins passive");
        Check(ModContent.ItemType<FirstBreath>()!=ModContent.ItemType<RootPalmManual>(),"new content types registered independently");
        var oldPlayer=Main.player[0];
        try {
            Main.player[0]=new Player();Main.player[0].active=true;Main.player[0].dead=false;Main.player[0].position=new Microsoft.Xna.Framework.Vector2(700,500);
            guardian.Center=new Microsoft.Xna.Framework.Vector2(500,500);guardian.target=0;guardian.ai[0]=1;guardian.ai[1]=0;guardian.ai[2]=1;
            for(int tick=0;tick<59;tick++){guardian.ModNPC.AI();Check(guardian.damage==0 && guardian.ai[0]==1,"dash windup is harmless for 59 ticks");}
            guardian.ModNPC.AI();Check(guardian.ai[0]==2,"dash starts after 60 ticks");
            guardian.ModNPC.AI();Check(guardian.velocity.X==7&&guardian.damage==27,"dash has motion and contact damage");
            guardian.ai[0]=3;guardian.ai[1]=0;guardian.ModNPC.AI();Check(guardian.damage==0,"recovery immediately disables contact");
            guardian.ai[0]=4;guardian.ai[1]=0;
            for(int tick=0;tick<59;tick++){guardian.ModNPC.AI();Check(guardian.damage==0 && guardian.ai[0]==4,"projectile windup stays harmless");}
            guardian.ModNPC.AI();int sparks=0;
            foreach(var projectile in Main.projectile)if(projectile.active&&projectile.type==ModContent.ProjectileType<HorizonSpark>()){sparks++;projectile.active=false;}
            Check(sparks==3&&guardian.ai[0]==5&&guardian.damage==0,"fan attack emits three real projectiles and enters recovery");
        } finally {Main.player[0]=oldPlayer;}
        Mod.Logger.Info("ORIGEM_AI PASS: full 60-tick windups, dash velocity/damage, harmless recovery, three-projectile fan creation");
        var foundation=new CultivationState();foundation.Learn();foundation.Practice=160;foundation.Qi=60;Check(foundation.Advance(),"legacy first advancement");foundation.Qi=90;Check(!foundation.EstablishFoundation(false),"foundation requires actual world victory");Check(foundation.EstablishFoundation(true)&&foundation.MaxQi==130,"earned second realm");foundation.Method=2;foundation.Recovery=0;foundation.Qi=30;Check(foundation.Spend(10,12,30)&&foundation.Qi==21,"wind method trades energy economy for higher flow");
        var migrated=CultivationState.Restore(new TagCompound{["learned"]=true,["practice"]=80,["realm"]=1,["qi"]=70f});Check(migrated.Realm==1&&migrated.Practice==80&&migrated.Method==0,"schema-one migration preserves existing progress");
        Mod.Logger.Info("ORIGEM_020 PASS: foundation gated by victory, method cost tradeoff, old-save migration");
        Mod.Logger.Info("ORIGEM_TEST PASS: earned learning, exact costs, cooldown, overload, hit training, unlocks, advancement, binary persistence, invalid saves, death, combat windows and NPC defaults");
    }
    public override void PostAddRecipes(){
        if(Environment.GetEnvironmentVariable("ORIGEM_TEST")!="1")return;
        foreach(int type in new[]{ModContent.ItemType<FirstBreath>(),ModContent.ItemType<RootPalmManual>(),ModContent.ItemType<HorizonCut>(),ModContent.ItemType<MountainGuard>(),ModContent.ItemType<HorizonSeal>(),ModContent.ItemType<JadeTrainingBlade>(),ModContent.ItemType<SpringStaff>(),ModContent.ItemType<MistStep>(),ModContent.ItemType<JadeElixir>(),ModContent.ItemType<ThreePaths>()}){
            bool found=false;for(int i=0;i<Recipe.numRecipes;i++)if(Main.recipe[i].createItem.type==type){found=true;break;}
            Check(found,"craftable progression item "+type);
        }
        Mod.Logger.Info("ORIGEM_RECIPES PASS: ten progression, weapon, method and consumable recipes registered");
    }
}
