using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public sealed class HorizonGuardian : ModNPC
{
    private int hurtTicks;
    private ClipClock animation;
    public override void HitEffect(NPC.HitInfo hit){if(NPC.life>0)hurtTicks=8;}
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override void SetDefaults(){
        NPC.width=56;NPC.height=80;NPC.lifeMax=1600;NPC.defense=9;NPC.damage=14;NPC.boss=true;
        NPC.aiStyle=-1;NPC.knockBackResist=0;NPC.value=Item.buyPrice(gold:2);NPC.npcSlots=5;
        NPC.HitSound=SoundID.NPCHit4;NPC.DeathSound=SoundID.NPCDeath14;Music=MusicID.Boss2;
    }
    public static bool ContactWindow(int phase)=>phase==0||phase==2;
    public override void PostAI()=>animation.Update(Math.Abs(NPC.velocity.X)>0.3f?ReadyArt.GuardianWalk:ReadyArt.GuardianIdle);
    public override void AI(){
        if(hurtTicks>0)hurtTicks--;
        NPC.TargetClosest(false);var p=Main.player[NPC.target];
        if(!p.active||p.dead||Vector2.Distance(NPC.Center,p.Center)>2400){NPC.EncourageDespawn(90);NPC.velocity.X*=0.96f;return;}
        int phase=(int)NPC.ai[0];NPC.ai[1]++;
        NPC.damage=phase==2?27:phase==0?14:0;
        if(phase==0){
            NPC.direction=p.Center.X>NPC.Center.X?1:-1;
            NPC.velocity.X=MathHelper.Lerp(NPC.velocity.X,NPC.direction*1.8f,0.045f);
            if(NPC.collideX&&NPC.collideY)NPC.velocity.Y=-6;
            if(NPC.ai[1]>=(NPC.life<NPC.lifeMax/2?95:140)){NPC.ai[2]=NPC.direction;Change(1);}
        }else if(phase==1){
            NPC.velocity.X*=0.8f;
            if(NPC.ai[1]>=60)Change(2);
        }else if(phase==2){
            NPC.velocity.X=NPC.ai[2]*7;
            if(NPC.ai[1]>=36||NPC.collideX)Change(3);
        }else if(phase==3){
            NPC.velocity.X*=0.86f;
            if(NPC.ai[1]>=65)Change(4);
        }else if(phase==4){
            NPC.velocity.X*=0.8f;
            if(NPC.ai[1]>=60){
                if(Main.netMode!=NetmodeID.MultiplayerClient){
                    Vector2 direction=(p.Center-NPC.Center).SafeNormalize(Vector2.UnitX);
                    int count=NPC.life<NPC.lifeMax/2?5:3;
                    for(int i=0;i<count;i++)Projectile.NewProjectile(NPC.GetSource_FromAI(),NPC.Center,direction.RotatedBy((i-(count-1)/2f)*0.22f)*4.5f,ModContent.ProjectileType<HorizonSpark>(),11,1,Main.myPlayer);
                }
                Change(5);
            }
        }else {NPC.velocity.X*=0.85f;if(NPC.ai[1]>=70)Change(0);}
        NPC.damage=ContactWindow((int)NPC.ai[0])?(NPC.ai[0]==2?27:14):0;
    }
    private void Change(int phase){NPC.ai[0]=phase;NPC.ai[1]=0;NPC.netUpdate=true;}
    public override void OnKill(){OriginWorld.GuardianDefeated=true;Effects.Burst(NPC.Center,Art.Ember,24,5);Effects.Death(ReadyArt.GuardianDeath,NPC.Bottom,102,NPC.direction);Effects.Shake(3);}
    public override void ModifyNPCLoot(NPCLoot loot){loot.Add(ItemDropRule.Common(ModContent.ItemType<JadeShard>(),1,8,12));loot.Add(ItemDropRule.Common(ModContent.ItemType<QuietJade>()));loot.Add(ItemDropRule.Common(ModContent.ItemType<HorizonCore>()));}
    public override bool PreDraw(SpriteBatch b,Vector2 screenPos,Color lightColor){
        Vector2 c=NPC.Bottom-screenPos-new Vector2(0,35);
        var clip=hurtTicks>0?ReadyArt.GuardianHurt:NPC.ai[0]==4?ReadyArt.GuardianAttack:NPC.ai[0]==2||Math.Abs(NPC.velocity.X)>0.3f?ReadyArt.GuardianWalk:ReadyArt.GuardianIdle;
        int frame=hurtTicks>0?clip.At(8-hurtTicks,false):NPC.ai[0]==4?clip.Progress(NPC.ai[1]/60f):animation.Frame;
        clip.Draw(b,NPC.Bottom-screenPos,102,NPC.direction,frame,NPC.GetAlpha(lightColor));
        if(NPC.ai[0]==1){var start=NPC.Bottom-screenPos-new Vector2(0,4);Art.Line(b,start,start+new Vector2(NPC.ai[2]*160,0),Art.Ember*(0.35f+NPC.ai[1]/100),4);}
        if(NPC.ai[0]==4)Art.Ring(b,NPC.Center-screenPos,45+(float)Math.Sin(Main.GameUpdateCount*0.2f)*3,Art.Ember*0.7f);
        return false;
    }
}
