using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public abstract class OriginItem : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Icon"+Glyph;
    protected virtual int Glyph => 0;
    public override bool PreDrawInInventory(SpriteBatch b,Vector2 position,Rectangle frame,Color drawColor,Color itemColor,Vector2 origin,float scale) {
        SpriteBank.Icon(b,position,Glyph,30*scale);return false;
    }
    public override bool PreDrawInWorld(SpriteBatch b,Color light,Color alpha,ref float rotation,ref float scale,int whoAmI) {
        SpriteBank.Icon(b,Item.Center-Main.screenPosition,Glyph,26,light);return false;
    }
    protected void Tool() { Item.width=Item.height=28;Item.useStyle=ItemUseStyleID.HoldUp;Item.useTime=Item.useAnimation=30;Item.rare=ItemRarityID.Blue;Item.value=Item.buyPrice(silver:30); }
    public override bool CanUseItem(Player player) => Main.netMode == NetmodeID.SinglePlayer;
}
public sealed class JadeShard : OriginItem
{
    public override void SetDefaults() { Item.width=14;Item.height=22;Item.maxStack=9999;Item.value=Item.sellPrice(silver:1);Item.rare=ItemRarityID.Blue; }
}
public sealed class FirstBreath : OriginItem
{
    protected override int Glyph=>1;
    public override void SetDefaults() {Tool();Item.value=Item.buyPrice(silver:10);}
    public override bool? UseItem(Player player) {
        if(player.whoAmI==Main.myPlayer) {
            bool learned=player.GetModPlayer<Cultivator>().State.Learn();
            Main.NewText(Language.GetTextValue("Mods.AlemDosCeusOrigem.Messages."+(learned?"Learned":"AlreadyLearned")),Art.Jade);
        }
        return true;
    }
    public override void AddRecipes()=>CreateRecipe().AddIngredient(ItemID.Wood,10).AddIngredient(ItemID.FallenStar).AddTile(TileID.WorkBenches).Register();
}
public abstract class TechniqueItem : OriginItem
{
    protected abstract int Cost {get;}
    protected abstract int RequiredPractice {get;}
    public override void SetDefaults() {
        Tool();Item.useStyle=ItemUseStyleID.Shoot;Item.noMelee=true;Item.noUseGraphic=true;
        Item.damage=20;Item.knockBack=3;Item.DamageType=DamageClass.Melee;
        Item.shoot=ModContent.ProjectileType<RootPalm>();Item.shootSpeed=1;
    }
    private CultivationSkill Skill => this is HorizonCut ? CultivationSkill.Wave : CultivationSkill.Palm;
    public override bool CanUseItem(Player player) => CultivationActions.CanUseManual(player,Skill);
    public override bool Shoot(Player player,EntitySource_ItemUse_WithAmmo source,Vector2 position,Vector2 velocity,int type,int damage,float knockback) {
        CultivationActions.Activate(player,Skill,Main.MouseWorld,true,damage,source);
        return false;
    }
}
public sealed class RootPalmManual : TechniqueItem
{
    protected override int Glyph=>2;
    protected override int Cost=>10;
    protected override int RequiredPractice=>0;
    public override void AddRecipes()=>CreateRecipe().AddIngredient(ItemID.Wood,8).AddTile(TileID.WorkBenches).Register();
}
public sealed class HorizonCut : TechniqueItem
{
    protected override int Glyph=>3;
    protected override int Cost=>18;
    protected override int RequiredPractice=>20;
    public override void SetDefaults(){base.SetDefaults();Item.damage=28;Item.useTime=Item.useAnimation=40;}
    public override void AddRecipes()=>CreateRecipe().AddIngredient<JadeShard>(3).AddIngredient(ItemID.FallenStar).AddTile(TileID.WorkBenches).Register();
}
public sealed class MountainGuard : OriginItem
{
    protected override int Glyph=>4;
    public override void SetDefaults()=>Tool();
    public override bool CanUseItem(Player p)=>CultivationActions.CanUseManual(p,CultivationSkill.Guard);
    public override bool? UseItem(Player p)=>CultivationActions.Activate(p,CultivationSkill.Guard,Main.MouseWorld,true);
    public override void AddRecipes()=>CreateRecipe().AddIngredient<JadeShard>(3).AddIngredient(ItemID.StoneBlock,20).AddTile(TileID.WorkBenches).Register();
}
public sealed class HorizonSeal : OriginItem
{
    protected override int Glyph=>5;
    public override void SetDefaults(){Tool();Item.useTime=Item.useAnimation=45;}
    public override bool CanUseItem(Player p)=>base.CanUseItem(p)&&p.GetModPlayer<Cultivator>().State.WaveKnown&&!NPC.AnyNPCs(ModContent.NPCType<HorizonGuardian>());
    public override bool? UseItem(Player p) {
        if(p.whoAmI!=Main.myPlayer || !CanUseItem(p))return false;
        if(OriginWorld.TryGround(p.Center+new Vector2(p.direction*320,0),56,80,out Vector2 at)){
            NPC.NewNPC(p.GetSource_ItemUse(Item),(int)at.X,(int)at.Y,ModContent.NPCType<HorizonGuardian>());
            return true;
        }
        Main.NewText(Language.GetTextValue("Mods.AlemDosCeusOrigem.Messages.NoSpace"),Art.Ember);return false;
    }
    public override void AddRecipes()=>CreateRecipe().AddIngredient<JadeShard>(5).AddIngredient(ItemID.StoneBlock,30).AddTile(TileID.WorkBenches).Register();
}
public sealed class QuietJade : OriginItem
{
    protected override int Glyph=>6;
    public override void SetDefaults(){Item.width=Item.height=24;Item.accessory=true;Item.rare=ItemRarityID.Green;Item.value=Item.sellPrice(gold:1);}
    public override void UpdateAccessory(Player p,bool hideVisual){if(Main.netMode==NetmodeID.SinglePlayer)p.GetModPlayer<Cultivator>().State.BonusQi=20;}
}
