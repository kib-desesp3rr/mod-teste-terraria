using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using ReLogic.Content;
using Terraria;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public sealed class BaihuBoss : ModNPC
{
    private const int Intro = 0;
    private const int Pursue = 1;
    private const int ChargeWindup = 2;
    private const int Charge = 3;
    private const int Recovery = 4;
    private const int ClawWindup = 5;
    private const int Claw = 6;
    private const int Leap = 7;
    private const int ShardVolley = 8;
    private const int RingBurst = 9;

    private int Phase => NPC.life * 100 / Math.Max(1, NPC.lifeMax) <= 35 ? 2 : NPC.life * 100 / Math.Max(1, NPC.lifeMax) <= 70 ? 1 : 0;

    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Baihu_Idle";

    public override void SetStaticDefaults()
    {
        Main.npcFrameCount[Type] = 1;
        NPCID.Sets.BossBestiaryPriority.Add(Type);
    }

    public override void SetDefaults()
    {
        NPC.width = 96;
        NPC.height = 70;
        NPC.lifeMax = Main.masterMode ? 22000 : Main.expertMode ? 16500 : 12000;
        NPC.defense = 12;
        NPC.damage = 0;
        NPC.boss = true;
        NPC.aiStyle = -1;
        NPC.knockBackResist = 0f;
        NPC.noGravity = false;
        NPC.noTileCollide = false;
        NPC.value = Item.buyPrice(gold: 6);
        NPC.npcSlots = 10f;
        NPC.HitSound = SoundID.NPCHit4;
        NPC.DeathSound = SoundID.NPCDeath14;
        Music = MusicID.Boss2;
    }

    public override void SetBestiary(BestiaryDatabase database, BestiaryEntry entry)
    {
        entry.Info.Add(BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Snow);
        entry.Info.Add(new FlavorTextBestiaryInfoElement("A Besta Celestial do Oeste caça através das neves e tempestades."));
    }

    public override void AI()
    {
        NPC.TargetClosest(false);
        Player target = Main.player[NPC.target];
        if (!target.active || target.dead || Vector2.Distance(NPC.Center, target.Center) > 2600f)
        {
            NPC.damage = 0;
            NPC.dontTakeDamage = false;
            NPC.EncourageDespawn(10);
            NPC.velocity.X *= 0.94f;
            return;
        }

        int state = (int)NPC.ai[0];
        int timer = (int)++NPC.ai[1];
        int phase = Phase;
        float distanceX = target.Center.X - NPC.Center.X;
        int targetDirection = distanceX >= 0 ? 1 : -1;
        NPC.direction = targetDirection;
        NPC.spriteDirection = targetDirection;
        NPC.dontTakeDamage = state == Intro;
        NPC.damage = 0;

        switch (state)
        {
            case Intro:
                NPC.velocity.X *= 0.85f;
                if (timer >= 85)
                    ChangeState(Pursue);
                break;

            case Pursue:
                NPC.velocity.X = MathHelper.Lerp(NPC.velocity.X, targetDirection * (phase == 0 ? 2.4f : 3.1f), 0.06f);
                if (NPC.collideX && NPC.velocity.Y == 0f)
                    NPC.velocity.Y = -6.5f;
                int cooldown = phase == 0 ? 112 : phase == 1 ? 94 : 78;
                if (timer >= cooldown && Main.netMode != NetmodeID.MultiplayerClient)
                {
                    if (phase == 0)
                        ChangeState(target.Center.Y < NPC.Center.Y - 72f && Main.rand.NextBool(2) ? Leap : Math.Abs(distanceX) > 260f ? ChargeWindup : ClawWindup);
                    else if (phase == 1)
                        ChangeState(target.Center.Y < NPC.Center.Y - 72f && Main.rand.NextBool(3) ? Leap : Main.rand.NextBool(2) ? (Math.Abs(distanceX) > 220f ? ChargeWindup : ClawWindup) : ShardVolley);
                    else
                        ChangeState(Main.rand.Next(3) == 0 ? ChargeWindup : Main.rand.NextBool() ? ShardVolley : RingBurst);
                }
                break;

            case ChargeWindup:
                NPC.velocity.X *= 0.78f;
                NPC.damage = 0;
                if (timer >= 38)
                {
                    NPC.ai[2] = targetDirection;
                    ChangeState(Charge);
                }
                break;

            case Charge:
                NPC.damage = timer >= 5 ? (phase == 0 ? 24 : phase == 1 ? 31 : 38) : 0;
                NPC.velocity.X = NPC.ai[2] * (phase == 0 ? 8.2f : phase == 1 ? 9.5f : 10.5f);
                if (timer >= 30 || NPC.collideX)
                {
                    NPC.velocity.X *= 0.45f;
                    ChangeState(Recovery);
                }
                break;

            case ClawWindup:
                NPC.velocity.X *= 0.82f;
                if (timer >= 42)
                    ChangeState(Claw);
                break;

            case Claw:
                NPC.damage = timer <= 14 ? (phase == 0 ? 22 : phase == 1 ? 29 : 35) : 0;
                if (timer == 5 && Main.netMode != NetmodeID.MultiplayerClient)
                {
                    int count = phase == 0 ? 3 : phase == 1 ? 5 : 7;
                    FireFan(target, count, phase == 0 ? 5f : 6f, 0.34f, 18 + phase * 3);
                }
                if (timer >= 30)
                    ChangeState(Recovery);
                break;

            case Leap:
                NPC.damage = 0;
                if (timer == 1)
                    NPC.velocity = new Vector2(targetDirection * 4f, -10.5f);
                if (timer >= 32 && NPC.velocity.Y == 0f)
                    ChangeState(Recovery);
                else if (timer >= 75)
                    ChangeState(Recovery);
                break;

            case ShardVolley:
                NPC.velocity.X *= 0.9f;
                if (timer == 28 && Main.netMode != NetmodeID.MultiplayerClient)
                {
                    int count = phase == 0 ? 3 : phase == 1 ? 5 : 7;
                    FireFan(target, count, phase == 0 ? 5.5f : 6.2f, 0.22f, 19 + phase * 3);
                }
                if (timer >= 56)
                    ChangeState(Recovery);
                break;

            case RingBurst:
                NPC.velocity.X *= 0.85f;
                if (timer == 42 && Main.netMode != NetmodeID.MultiplayerClient)
                {
                    int count = 8 + phase * 2;
                    for (int i = 0; i < count; i++)
                    {
                        float angle = MathHelper.TwoPi * i / count;
                        Vector2 velocity = angle.ToRotationVector2() * (4.6f + phase * 0.6f);
                        SpawnShard(NPC.Center, velocity, 17 + phase * 3);
                    }
                }
                if (timer >= 72)
                    ChangeState(Recovery);
                break;

            case Recovery:
                NPC.velocity.X *= 0.84f;
                if (timer >= (phase == 0 ? 38 : 32))
                    ChangeState(Pursue);
                break;

            default:
                ChangeState(Pursue);
                break;
        }

        if (state == ClawWindup || state == ChargeWindup || state == ShardVolley || state == RingBurst)
            NPC.velocity.X *= 0.94f;
    }

    private void ChangeState(int state)
    {
        NPC.ai[0] = state;
        NPC.ai[1] = 0f;
        NPC.netUpdate = true;
    }

    private void FireFan(Player target, int count, float speed, float spread, int damage)
    {
        Vector2 aim = (target.Center - NPC.Center).SafeNormalize(Vector2.UnitX);
        for (int i = 0; i < count; i++)
        {
            float offset = (i - (count - 1) / 2f) * spread;
            SpawnShard(NPC.Center, aim.RotatedBy(offset) * speed, damage);
        }
    }

    private void SpawnShard(Vector2 position, Vector2 velocity, int damage)
    {
        Projectile.NewProjectile(NPC.GetSource_FromAI(), position, velocity, ModContent.ProjectileType<BaihuShard>(), damage, 0f, Main.myPlayer);
    }

    public override void OnKill()
    {
        Effects.Burst(NPC.Center, new Color(126, 204, 255), 30, 5f);
        Effects.Shake(3f);
    }

    public override void ModifyNPCLoot(NPCLoot loot)
    {
        var normal = new LeadingConditionRule(new Conditions.NotExpert());
        normal.OnSuccess(ItemDropRule.Common(ModContent.ItemType<BaihuEssence>(), 1, 8, 14));
        normal.OnSuccess(ItemDropRule.Common(ModContent.ItemType<BaihuClaw>()));
        normal.OnSuccess(ItemDropRule.Common(ModContent.ItemType<BaihuEye>(), 4));
        loot.Add(normal);
        loot.Add(ItemDropRule.BossBag(ModContent.ItemType<BaihuTreasureBag>()));
    }

    public override bool PreDraw(SpriteBatch spriteBatch, Vector2 screenPos, Color drawColor)
    {
        int state = (int)NPC.ai[0];
        bool charging = state == Charge;
        bool winding = state == ChargeWindup;
        bool clawing = state == Claw;
        bool moving = Math.Abs(NPC.velocity.X) > 0.4f || state == Leap;
        string pose = clawing ? "Claw" : charging || winding ? "Charge" : moving ? "Walk" : "Idle";
        string texturePath = $"AlemDosCeusOrigem/Assets/Baihu/Baihu_{pose}";
        Texture2D texture = ModContent.Request<Texture2D>(texturePath, AssetRequestMode.ImmediateLoad).Value;
        Vector2 origin = new(texture.Width * 0.5f, texture.Height * 0.94f);
        float bob = moving ? (float)Math.Sin(Main.GameUpdateCount * 0.28f) * 2.5f : (float)Math.Sin(Main.GameUpdateCount * 0.055f) * 1.7f;
        Vector2 position = NPC.Bottom - screenPos + new Vector2(0f, 2f + bob);
        SpriteEffects flip = NPC.spriteDirection < 0 ? SpriteEffects.FlipHorizontally : SpriteEffects.None;
        float scale = 0.145f;
        float tilt = charging ? -0.035f : clawing ? 0.025f : moving ? (float)Math.Sin(Main.GameUpdateCount * 0.28f) * 0.018f : 0f;
        float pulse = 0.5f + 0.5f * (float)Math.Sin(Main.GameUpdateCount * (Phase == 0 ? 0.06f : 0.12f));
        Color aura = Phase == 0 ? new Color(75, 164, 235) : Phase == 1 ? new Color(58, 186, 255) : new Color(120, 222, 255);

        Art.Ring(spriteBatch, position + new Vector2(10f, -106f), 37f + pulse * 3f, aura * (0.18f + Phase * 0.08f));
        if (winding)
        {
            Vector2 start = NPC.Bottom - screenPos + new Vector2(0f, -8f);
            Vector2 end = start + new Vector2(NPC.direction * (105f + Math.Min(100f, NPC.ai[1] * 2.6f)), 0f);
            Art.Line(spriteBatch, start, end, aura * (0.2f + pulse * 0.3f), 3f);
        }

        if (charging)
        {
            for (int i = 3; i >= 1; i--)
                Main.EntitySpriteDraw(texture, position - NPC.velocity * i * 0.55f, null, new Color(105, 202, 255, 0) * (0.3f / i), tilt, origin, scale, flip, 0);
        }

        Main.EntitySpriteDraw(texture, position, null, NPC.GetAlpha(drawColor), tilt, origin, scale, flip, 0);
        if (clawing)
            Art.Ring(spriteBatch, NPC.Center - screenPos + new Vector2(NPC.direction * 45f, -2f), 30f + pulse * 13f, new Color(134, 211, 255) * 0.68f);
        if (Phase > 0)
        {
            float glow = 0.18f + 0.08f * pulse;
            Lighting.AddLight(NPC.Center, 0.18f, 0.38f + glow, 0.68f + glow);
        }
        return false;
    }
}
