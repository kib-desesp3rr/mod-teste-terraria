using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public sealed class HorizonCore : OriginItem
{
    protected override int Glyph=>10;
    public override void SetDefaults(){Item.width=Item.height=24;Item.maxStack=9999;Item.rare=ItemRarityID.Green;Item.value=Item.sellPrice(silver:25);}
}
public abstract class TrainingWeapon : OriginItem
{
    protected abstract bool IsStaff{get;}
    protected override int Glyph=>IsStaff?8:7;
    public override void SetDefaults(){Tool();Item.useStyle=ItemUseStyleID.Shoot;Item.noMelee=true;Item.noUseGraphic=true;Item.DamageType=DamageClass.Melee;Item.damage=IsStaff?12:15;Item.knockBack=IsStaff?5:2;Item.useTime=Item.useAnimation=IsStaff?38:27;Item.shoot=ModContent.ProjectileType<WeaponArc>();Item.shootSpeed=1;}
    public override bool Shoot(Player p,EntitySource_ItemUse_WithAmmo source,Vector2 position,Vector2 velocity,int type,int damage,float knockback){
        if(p.whoAmI==Main.myPlayer && Main.netMode==NetmodeID.SinglePlayer){Vector2 aim=(Main.MouseWorld-p.MountedCenter).SafeNormalize(new Vector2(p.direction,0));Projectile.NewProjectile(source,p.MountedCenter,Vector2.Zero,type,damage,knockback,p.whoAmI,aim.ToRotation(),IsStaff?1:0,p.itemAnimationMax);}
        return false;
    }
}
public sealed class JadeTrainingBlade : TrainingWeapon
{
    protected override bool IsStaff=>false;
    public override void AddRecipes()=>CreateRecipe().AddIngredient(ItemID.Wood,10).AddIngredient<JadeShard>(2).AddTile(TileID.WorkBenches).Register();
}
public sealed class SpringStaff : TrainingWeapon
{
    protected override bool IsStaff=>true;
    public override void AddRecipes()=>CreateRecipe().AddIngredient(ItemID.Wood,18).AddTile(TileID.WorkBenches).Register();
}
public sealed class MistStep : OriginItem
{
    protected override int Glyph=>9;
    public override void SetDefaults()=>Tool();
    public override bool CanUseItem(Player p)=>CultivationActions.CanUseManual(p,CultivationSkill.Step);
    public override bool? UseItem(Player p)=>CultivationActions.Activate(p,CultivationSkill.Step,Main.MouseWorld,true);
    public override void AddRecipes()=>CreateRecipe().AddIngredient<JadeShard>(4).AddIngredient(ItemID.Feather,2).AddTile(TileID.WorkBenches).Register();
}
public sealed class JadeElixir : OriginItem
{
    protected override int Glyph=>11;
    public override void SetDefaults(){Tool();Item.maxStack=99;Item.consumable=true;Item.value=Item.buyPrice(silver:5);}
    public override bool CanUseItem(Player p){var s=p.GetModPlayer<Cultivator>().State;return base.CanUseItem(p)&&s.Learned&&s.ElixirCooldown==0&&(s.Qi<s.MaxQi||s.Strain>0);}
    public override bool? UseItem(Player p){
        if(p.whoAmI!=Main.myPlayer)return false;var s=p.GetModPlayer<Cultivator>().State;
        s.Qi=Math.Min(s.MaxQi,s.Qi+30);s.Strain=Math.Max(0,s.Strain-15);s.ElixirCooldown=900;Effects.Burst(p.Center,Art.Jade,10,2);return true;
    }
    public override void AddRecipes()=>CreateRecipe(2).AddIngredient<JadeShard>().AddIngredient(ItemID.BottledWater).AddIngredient(ItemID.Daybloom).AddTile(TileID.Bottles).Register();
}
public sealed class ThreePaths : OriginItem
{
    protected override int Glyph=>12;
    public override void SetDefaults()=>Tool();
    public override bool CanUseItem(Player p)=>base.CanUseItem(p)&&p.GetModPlayer<Cultivator>().State.Realm>=1;
    public override bool? UseItem(Player p){if(p.whoAmI!=Main.myPlayer)return false;var s=p.GetModPlayer<Cultivator>().State;s.Method=(s.Method+1)%3;Main.NewText(Language.GetTextValue("Mods.AlemDosCeusOrigem.UI.Method"+s.Method),Art.Jade);return true;}
    public override void AddRecipes()=>CreateRecipe().AddIngredient<JadeShard>(8).AddIngredient(ItemID.Book).AddTile(TileID.WorkBenches).Register();
}
public sealed class WeaponArc : ModProjectile
{
    public override string Texture=>"Terraria/Images/MagicPixel";
    private float progress,angle,reach;
    public override void SetDefaults(){Projectile.width=Projectile.height=16;Projectile.DamageType=DamageClass.Melee;Projectile.friendly=true;Projectile.timeLeft=90;Projectile.tileCollide=false;Projectile.penetrate=-1;Projectile.usesLocalNPCImmunity=true;Projectile.localNPCHitCooldown=-1;Projectile.ownerHitCheck=true;}
    public override bool ShouldUpdatePosition()=>false;
    public override bool? CanDamage()=>progress>=0.25f&&progress<=0.72f?null:false;
    public override void AI(){
        var p=Main.player[Projectile.owner];if(!p.active||p.dead||p.itemAnimation<=0){Projectile.Kill();return;}
        progress=Math.Clamp(1-p.itemAnimation/Math.Max(1,Projectile.ai[2]),0,1);
        // Freeze swing facing at spawn; turning the cursor must not reverse an active arc.
        int facing=Math.Cos(Projectile.ai[0])<0?-1:1;
        p.direction=facing;
        angle=Projectile.ai[0]+(Projectile.ai[1]==0?MathHelper.Lerp(-1.4f,1.4f,progress)*facing:0);
        reach=Projectile.ai[1]==1?52+(float)Math.Sin(progress*MathHelper.Pi)*18:52;
        Projectile.Center=p.MountedCenter+angle.ToRotationVector2()*reach;
        p.heldProj=Projectile.whoAmI;p.SetCompositeArmFront(true,Player.CompositeArmStretchAmount.Full,angle-MathHelper.PiOver2);
        if(Main.GameUpdateCount%2==0&&progress>=0.25f&&progress<0.72f)Effects.Emit(Projectile.Center,Vector2.Zero,Projectile.ai[1]==1?Art.Parchment:Art.Jade,12,1.5f);
    }
    public override bool? Colliding(Rectangle projHitbox,Rectangle targetHitbox){float point=0;var p=Main.player[Projectile.owner];return Collision.CheckAABBvLineCollision(targetHitbox.TopLeft(),targetHitbox.Size(),p.MountedCenter,p.MountedCenter+angle.ToRotationVector2()*reach,8,ref point);}
    public override void OnHitNPC(NPC target,NPC.HitInfo hit,int damageDone)=>Effects.Burst(target.Center,Art.Jade,6,2);
    public override bool PreDraw(ref Color color){var p=Main.player[Projectile.owner];bool staff=Projectile.ai[1]==1;Vector2 start=p.GetFrontHandPosition(Player.CompositeArmStretchAmount.Full,angle-MathHelper.PiOver2)-Main.screenPosition;if(staff)start+=angle.ToRotationVector2()*(reach-70);SpriteBank.Weapon(Main.spriteBatch,start,staff?8:7,staff?48:38,angle,color);return false;}
}
