using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;

namespace AlemDosCeusOrigem.Content;

public sealed class BaihuShard : ModProjectile
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Fragmentos_Gelo/Fragmentos_Gelo_01";

    public override void SetDefaults()
    {
        Projectile.width = 18;
        Projectile.height = 18;
        Projectile.hostile = true;
        Projectile.friendly = false;
        Projectile.tileCollide = false;
        Projectile.ignoreWater = true;
        Projectile.penetrate = 1;
        Projectile.timeLeft = 240;
        Projectile.light = 0.35f;
    }

    public override void AI()
    {
        Projectile.rotation = Projectile.velocity.ToRotation() + MathHelper.PiOver2;
        if (Main.rand.NextBool(3))
            Dust.NewDust(Projectile.position, Projectile.width, Projectile.height, DustID.IceTorch, 0f, 0f, 150, default, 0.8f);
    }

    public override void OnHitPlayer(Player target, Player.HurtInfo info)
    {
        target.AddBuff(BuffID.Frostburn, 120);
    }

    public override bool PreDraw(ref Color lightColor)
    {
        int frame = (int)(Main.GameUpdateCount / 5) % 8;
        string framePath = $"AlemDosCeusOrigem/Assets/Baihu/Fragmentos_Gelo/Fragmentos_Gelo_{frame + 1:00}";
        Texture2D texture = ModContent.Request<Texture2D>(framePath).Value;
        float scale = 0.09f;
        Color tint = Color.White * 0.9f;
        Main.EntitySpriteDraw(texture, Projectile.Center - Main.screenPosition, null, tint, Projectile.rotation,
            texture.Size() * 0.5f, scale, SpriteEffects.None, 0);
        return false;
    }
}
