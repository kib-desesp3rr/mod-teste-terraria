using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.Localization;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

[AutoloadHead]
public sealed class Wayfarer : ModNPC
{
    private ClipClock animation;
    public override void PostAI()=>animation.Update(System.Math.Abs(NPC.velocity.X)>0.2f?ReadyArt.MentorWalk:ReadyArt.MentorIdle);
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override string HeadTexture=>"AlemDosCeusOrigem/Assets/Icon1";
    public override bool CanChat()=>true;
    public override bool CheckActive()=>false;
    public override System.Collections.Generic.List<string> SetNPCNameList()=>new(){"Shen das Nascentes"};
    public override void SetDefaults(){NPC.width=22;NPC.height=48;NPC.lifeMax=250;NPC.defense=30;NPC.damage=0;NPC.friendly=true;NPC.townNPC=true;NPC.aiStyle=7;NPC.knockBackResist=0.5f;NPC.HitSound=SoundID.NPCHit1;NPC.DeathSound=SoundID.NPCDeath1;}
    public override bool CanTownNPCSpawn(int numTownNPCs)=>Main.netMode==NetmodeID.SinglePlayer;
    public override bool CheckConditions(int left,int right,int top,int bottom)=>true;
    public override string GetChat()=>!Main.LocalPlayer.GetModPlayer<Cultivator>().State.Learned?"Bem-vindo. Reúna 10 madeiras e uma estrela caída; perto de uma bancada, abra o caderno pelo botão do HUD ou pela tecla "+CultivationJournal.Key(OriginMod.Journal)+" e aprenda o método na Jornada. Depois fabrique a Palma na Oficina. Posso vender manuais se preferir.":Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue.Mentor");
    public override void SetChatButtons(ref string button,ref string button2){button=Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue.Advice");button2=Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue.Shop");}
    public override void OnChatButtonClicked(bool firstButton,ref string shopName){
        if(firstButton){var s=Main.LocalPlayer.GetModPlayer<Cultivator>().State;Main.npcChatText=!s.Learned?GetChat():Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue."+(s.Practice<20?"Palm":s.Practice<40?"Wave":s.Practice<80?"Guard":"Advance"));}
        else shopName="Supplies";
    }
    public override void AddShops()=>new NPCShop(Type,"Supplies").Add<FirstBreath>().Add<RootPalmManual>().Add<HorizonCut>().Add<MountainGuard>().Add<MistStep>().Add<SpringStaff>().Add<HorizonSeal>().Add<JadeElixir>().Register();
    public override bool PreDraw(SpriteBatch b,Vector2 screenPos,Color lightColor){var clip=animation.Clip??ReadyArt.MentorIdle;clip.Draw(b,NPC.Bottom-screenPos,55,NPC.direction,animation.Frame,NPC.GetAlpha(lightColor));return false;}
}
public sealed class StillnessNode : ModNPC
{
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override void SetDefaults(){NPC.width=32;NPC.height=44;NPC.lifeMax=1000;NPC.friendly=true;NPC.dontTakeDamage=true;NPC.noGravity=true;NPC.noTileCollide=true;NPC.aiStyle=-1;}
    public override bool CanChat()=>true;
    public override bool CheckActive()=>false;
    public override void AI(){NPC.velocity=Vector2.Zero;if(!Main.dedServ)Lighting.AddLight(NPC.Center,0.1f,0.35f,0.23f);}
    public override string GetChat(){OriginWorld.NodeDiscovered=true;return Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue.Node");}
    public override void SetChatButtons(ref string button,ref string button2){button=Main.LocalPlayer.GetModPlayer<Cultivator>().State.Realm==1?"Estabelecer fundação":"Abrir circulação";}
    public override void OnChatButtonClicked(bool firstButton,ref string shopName){
        if(!firstButton||Main.netMode!=NetmodeID.SinglePlayer)return;
        Player p=Main.LocalPlayer;var s=p.GetModPlayer<Cultivator>().State;
        if(s.Realm>=2){Main.npcChatText="Sua Fundação Celeste já foi consolidada.";return;}
        int shard=ModContent.ItemType<JadeShard>(),total=0;foreach(var item in p.inventory)if(item.type==shard)total+=item.stack;
        bool foundation=s.Realm==1;
        int needed=foundation?12:5;
        if(total<needed || (foundation&&!p.HasItem(ModContent.ItemType<HorizonCore>())) || !(foundation?s.EstablishFoundation(OriginWorld.GuardianDefeated):s.Advance())){Main.npcChatText=Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue."+(foundation?"FoundationRequirements":"Requirements"));return;}
        for(int i=0;i<needed;i++)p.ConsumeItem(shard);
        if(foundation)p.ConsumeItem(ModContent.ItemType<HorizonCore>());
        Main.npcChatText=Language.GetTextValue("Mods.AlemDosCeusOrigem.Dialogue."+(foundation?"FoundationAdvanced":"Advanced"));
        if(!Main.dedServ)for(int i=0;i<24;i++){var d=Dust.NewDustPerfect(p.Center,DustID.GemEmerald,(i*MathHelper.TwoPi/24).ToRotationVector2()*3,50,Art.Jade);d.noGravity=true;}
    }
    public override bool PreDraw(SpriteBatch b,Vector2 screenPos,Color lightColor){
        Vector2 c=NPC.Center-screenPos+new Vector2(0,(float)Math.Sin(Main.GameUpdateCount*0.04f)*3);
        ReadyArt.Node.Draw(b,NPC.Bottom-screenPos,62);Art.Ring(b,c,27,Art.Jade*0.15f,12);return false;
    }
}
