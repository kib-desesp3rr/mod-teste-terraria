using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public abstract class QiAttack : ModProjectile
{
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override void SetDefaults() {
        Projectile.width=Projectile.height=24;Projectile.friendly=true;Projectile.DamageType=DamageClass.Melee;
        Projectile.penetrate=-1;Projectile.usesLocalNPCImmunity=true;Projectile.localNPCHitCooldown=-1;
        Projectile.tileCollide=false;Projectile.timeLeft=24;
    }
    public override void OnHitNPC(NPC target,NPC.HitInfo hit,int damageDone) {
        if(Main.dedServ)return;
        Effects.Burst(target.Center,Art.Jade,8,3);
        for(int i=0;i<6;i++){var d=Dust.NewDustPerfect(target.Center,DustID.GemEmerald,(i*MathHelper.TwoPi/6).ToRotationVector2()*2,100,Art.Jade,0.7f);d.noGravity=true;}
    }
}
public sealed class RootPalm : QiAttack
{
    private float age;
    public override void SetDefaults(){base.SetDefaults();Projectile.ownerHitCheck=true;}
    public override bool ShouldUpdatePosition()=>false;
    public static bool Active(float tick)=>tick>=7 && tick<=13;
    public override bool? CanDamage()=>Active(age)?null:false;
    public override void AI() {
        var p=Main.player[Projectile.owner];if(!p.active||p.dead){Projectile.Kill();return;}
        age++;Projectile.rotation=Projectile.ai[0];
        var direction=Projectile.rotation.ToRotationVector2();Projectile.Center=p.MountedCenter+direction*(18+(float)Math.Sin(age/24*MathHelper.Pi)*29);
        p.direction=direction.X<0?-1:1;
        p.heldProj=Projectile.whoAmI;p.SetCompositeArmFront(true,Player.CompositeArmStretchAmount.Full,Projectile.rotation-MathHelper.PiOver2);
        if(!Main.dedServ)Lighting.AddLight(Projectile.Center,0.08f,0.24f,0.16f);
    }
    public override bool PreDraw(ref Color lightColor) {
        float opacity=(float)Math.Sin(age/24*MathHelper.Pi);
        var c=Projectile.Center-Main.screenPosition;var d=Projectile.rotation.ToRotationVector2();
        SpriteBank.Icon(Main.spriteBatch,c,2,28,Color.White*opacity,Projectile.rotation+MathHelper.PiOver2);
        Art.Ring(Main.spriteBatch,c,11+age*0.18f,Art.Jade*opacity*0.35f,12);return false;
    }
}
public sealed class JadeWave : QiAttack
{
    public override void SetDefaults(){base.SetDefaults();Projectile.timeLeft=44;Projectile.tileCollide=true;Projectile.penetrate=3;Projectile.width=Projectile.height=24;}
    public override void AI(){Projectile.rotation=Projectile.velocity.ToRotation();if(!Main.dedServ){Lighting.AddLight(Projectile.Center,0.08f,0.23f,0.15f);if(Main.GameUpdateCount%2==0)Effects.Emit(Projectile.Center,-Projectile.velocity*0.1f,Art.Jade,16,2);}}
    public override bool PreDraw(ref Color lightColor) {
        var b=Main.spriteBatch;var c=Projectile.Center-Main.screenPosition;
        float fade=Math.Min(1,Projectile.timeLeft/10f);
        for(int i=0;i<16;i++){
            float a=Projectile.rotation-1.25f+i*2.5f/16;
            Vector2 from=c+a.ToRotationVector2()*17,to=c+(a+2.5f/16).ToRotationVector2()*17;
            Art.Line(b,from,to,Art.Jade*fade,4);Art.Line(b,from,to,Art.Parchment*fade,1);
        }
        return false;
    }
}
public sealed class HorizonSpark : ModProjectile
{
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override void SetDefaults(){Projectile.width=Projectile.height=12;Projectile.hostile=true;Projectile.timeLeft=150;Projectile.tileCollide=true;Projectile.penetrate=1;}
    public override void AI(){Projectile.rotation=Projectile.velocity.ToRotation();if(!Main.dedServ)Lighting.AddLight(Projectile.Center,0.35f,0.15f,0.03f);}
    public override bool PreDraw(ref Color c){var at=Projectile.Center-Main.screenPosition;Art.Line(Main.spriteBatch,at-Projectile.velocity.SafeNormalize(Vector2.UnitX)*11,at+Projectile.velocity.SafeNormalize(Vector2.UnitX)*5,Art.Ember,5);return false;}
}
