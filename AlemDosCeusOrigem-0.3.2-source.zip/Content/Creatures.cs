using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Terraria;
using Terraria.GameContent.Bestiary;
using Terraria.GameContent.ItemDropRules;
using Terraria.ID;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public sealed class JadeTortoise : ModNPC
{
    private ClipClock animation;
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override void SetDefaults(){NPC.width=42;NPC.height=28;NPC.lifeMax=80;NPC.defense=6;NPC.damage=0;NPC.aiStyle=-1;NPC.knockBackResist=0.45f;NPC.HitSound=SoundID.NPCHit4;NPC.DeathSound=SoundID.NPCDeath1;NPC.value=60;}
    public override float SpawnChance(NPCSpawnInfo info)=>Main.netMode==NetmodeID.SinglePlayer&&Main.dayTime&&info.Player.ZoneOverworldHeight&&!info.PlayerInTown&&info.SpawnTileType==TileID.Grass?0.16f:0;
    public override void SetBestiary(BestiaryDatabase db,BestiaryEntry entry)=>entry.Info.Add(BestiaryDatabaseNPCsPopulator.CommonTags.SpawnConditions.Biomes.Surface);
    public override void AI(){
        if(NPC.ai[0]>0){NPC.ai[0]--;NPC.TargetClosest(false);NPC.direction=Main.player[NPC.target].Center.X>NPC.Center.X?1:-1;}
        else if(++NPC.ai[1]>=150){NPC.ai[1]=0;NPC.direction=Main.rand.NextBool()?1:-1;}
        NPC.damage=0;
        NPC.velocity.X=MathHelper.Lerp(NPC.velocity.X,NPC.direction*(NPC.ai[0]>0?1.5f:0.45f),0.08f);
        // Stinging is a bounded attack, not a looping attack animation for seven seconds.
        if(NPC.ai[0]>0){
            var target=Main.player[NPC.target];
            if(NPC.ai[2]==0&&target.active&&!target.dead&&Vector2.Distance(NPC.Center,target.Center)<64){NPC.ai[2]=1;NPC.ai[3]=0;}
            if(NPC.ai[2]>0){
                NPC.ai[3]++;NPC.velocity.X*=0.75f;
                if(NPC.ai[2]==1&&NPC.ai[3]>=22){NPC.ai[2]=2;NPC.ai[3]=0;}
                else if(NPC.ai[2]==2){NPC.damage=13;if(NPC.ai[3]>=18){NPC.ai[2]=3;NPC.ai[3]=0;NPC.damage=0;}}
                else if(NPC.ai[2]==3&&NPC.ai[3]>=32){NPC.ai[2]=0;NPC.ai[3]=0;}
            }
        }else {NPC.ai[2]=NPC.ai[3]=0;}
        if(NPC.collideX&&NPC.collideY)NPC.velocity.Y=-4;
        NPC.spriteDirection=NPC.direction;
        animation.Update(NPC.ai[2]==1||NPC.ai[2]==2?ReadyArt.ScorpionAttack:Math.Abs(NPC.velocity.X)>0.2f?ReadyArt.ScorpionWalk:ReadyArt.ScorpionIdle);
    }
    public override void HitEffect(NPC.HitInfo hit)=>NPC.ai[0]=420;
    public override void OnKill()=>Effects.Death(ReadyArt.ScorpionDeath,NPC.Bottom,44,NPC.direction);
    public override void ModifyNPCLoot(NPCLoot loot)=>loot.Add(ItemDropRule.Common(ModContent.ItemType<JadeShard>(),1,1,2));
    public override bool PreDraw(SpriteBatch b,Vector2 screenPos,Color lightColor){var clip=animation.Clip??ReadyArt.ScorpionIdle;int frame=clip==ReadyArt.ScorpionAttack?clip.Progress((NPC.ai[2]==1?NPC.ai[3]:22+NPC.ai[3])/40f):animation.Frame;clip.Draw(b,NPC.Bottom-screenPos,44,NPC.direction,frame,NPC.GetAlpha(lightColor));return false;}
}
public sealed class AshMoth : ModNPC
{
    private ClipClock animation;
    public override void OnKill()=>Effects.Death(ReadyArt.BatDeath,NPC.Bottom+new Vector2(0,8),44,NPC.direction);
    public override string Texture=>"Terraria/Images/MagicPixel";
    public override void SetDefaults(){NPC.width=36;NPC.height=26;NPC.lifeMax=70;NPC.defense=2;NPC.damage=15;NPC.aiStyle=-1;NPC.noGravity=true;NPC.knockBackResist=0.65f;NPC.HitSound=SoundID.NPCHit1;NPC.DeathSound=SoundID.NPCDeath1;NPC.value=90;}
    public override float SpawnChance(NPCSpawnInfo info)=>Main.netMode==NetmodeID.SinglePlayer&&!Main.dayTime&&info.Player.ZoneOverworldHeight&&!info.PlayerInTown?0.12f:0;
    public override void AI(){
        NPC.TargetClosest();var p=Main.player[NPC.target];
        if(p.dead||!p.active){NPC.velocity.Y-=0.03f;NPC.EncourageDespawn(60);return;}
        NPC.ai[0]=(NPC.ai[0]+1)%150;
        if(NPC.ai[0]<100){
            var desired=(p.Center+new Vector2((NPC.whoAmI%2==0?1:-1)*115,-90)-NPC.Center).SafeNormalize(Vector2.UnitY)*2.1f;
            NPC.velocity=Vector2.Lerp(NPC.velocity,desired,0.035f);
        }else if(NPC.ai[0]<125)NPC.velocity*=0.9f;
        else if(NPC.ai[0]==125)NPC.velocity=(p.Center-NPC.Center).SafeNormalize(Vector2.UnitX)*5.5f;
        if(NPC.collideX)NPC.velocity.X=-NPC.oldVelocity.X*0.6f;
        if(NPC.collideY)NPC.velocity.Y=-NPC.oldVelocity.Y*0.6f;
        NPC.damage=NPC.ai[0]>=100&&NPC.ai[0]<125?0:15;
        if(Math.Abs(NPC.velocity.X)>0.1f)NPC.direction=NPC.velocity.X<0?-1:1;
        animation.Update(NPC.ai[0]>=125?ReadyArt.BatAttack:NPC.ai[0]>=100?ReadyArt.BatIdle:ReadyArt.BatFly);
    }
    public override void ModifyNPCLoot(NPCLoot loot)=>loot.Add(ItemDropRule.Common(ModContent.ItemType<JadeShard>()));
    public override bool PreDraw(SpriteBatch b,Vector2 screenPos,Color lightColor){var c=NPC.Center-screenPos;var clip=animation.Clip??ReadyArt.BatFly;clip.Draw(b,NPC.Bottom-screenPos+new Vector2(0,8),44,NPC.direction,animation.Frame,NPC.GetAlpha(lightColor));if(NPC.ai[0]>=100&&NPC.ai[0]<125)Art.Ring(b,c,23,Art.Ember*0.7f,12);return false;}
}
