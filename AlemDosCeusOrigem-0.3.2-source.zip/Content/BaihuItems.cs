using Microsoft.Xna.Framework;
using Terraria;
using Terraria.DataStructures;
using Terraria.ID;
using Terraria.ModLoader;
using AlemDosCeusOrigem.Common;

namespace AlemDosCeusOrigem.Content;

public sealed class BaihuSummonItem : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Selo_Invocacao/Selo_Invocacao_01";

    public override void SetDefaults()
    {
        Item.width = 28;
        Item.height = 28;
        Item.maxStack = 20;
        Item.useStyle = ItemUseStyleID.HoldUp;
        Item.useTime = Item.useAnimation = 30;
        Item.rare = ItemRarityID.Orange;
        Item.consumable = true;
        Item.value = Item.buyPrice(silver: 50);
    }

    public override bool CanUseItem(Player player)
    {
        return Main.netMode == NetmodeID.SinglePlayer && player.ZoneSnow && !Main.dayTime && !NPC.AnyNPCs(ModContent.NPCType<BaihuBoss>());
    }

    public override bool? UseItem(Player player)
    {
        if (!OriginWorld.TryGround(player.Center + new Vector2(player.direction * 360f, 0f), 74, 58, out Vector2 feet))
        {
            Main.NewText("Baihu precisa de terreno firme e espaço para surgir.", new Color(132, 205, 255));
            return false;
        }

        int id = NPC.NewNPC(player.GetSource_ItemUse(Item), (int)feet.X, (int)feet.Y, ModContent.NPCType<BaihuBoss>());
        if (id < 0 || id >= Main.maxNPCs || !Main.npc[id].active)
            return false;

        Main.NewText("Baihu — O Tigre Branco do Oeste", new Color(132, 205, 255));
        return true;
    }

    public override void AddRecipes()
    {
        CreateRecipe().AddIngredient(ItemID.SnowBlock, 30).AddIngredient(ItemID.IceBlock, 10).AddIngredient(ItemID.FallenStar).AddTile(TileID.WorkBenches).Register();
        CreateRecipe().AddIngredient<BaihuEssence>(3).AddIngredient(ItemID.FallenStar, 2).AddTile(TileID.WorkBenches).Register();
    }
}

public sealed class BaihuEssence : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Essencia_Baihu_CONCEITO";

    public override void SetDefaults()
    {
        Item.width = 24;
        Item.height = 24;
        Item.maxStack = 9999;
        Item.rare = ItemRarityID.Orange;
        Item.value = Item.sellPrice(silver: 15);
    }
}

public sealed class BaihuClaw : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Garra_Celestial_CONCEITO";

    public override void SetDefaults()
    {
        Item.width = 38;
        Item.height = 38;
        Item.damage = 34;
        Item.DamageType = DamageClass.Melee;
        Item.useStyle = ItemUseStyleID.Swing;
        Item.useTime = 22;
        Item.useAnimation = 22;
        Item.knockBack = 4f;
        Item.UseSound = SoundID.Item1;
        Item.autoReuse = true;
        Item.rare = ItemRarityID.Orange;
        Item.value = Item.sellPrice(gold: 2);
    }

    public override void AddRecipes()
    {
        CreateRecipe().AddIngredient<BaihuEssence>(12).AddIngredient(ItemID.IceBlock, 30).AddTile(TileID.Anvils).Register();
    }
}

public sealed class BaihuBlade : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Lamina_Nevasca_CONCEITO";

    public override void SetDefaults()
    {
        Item.width = 42;
        Item.height = 42;
        Item.damage = 42;
        Item.DamageType = DamageClass.Melee;
        Item.useStyle = ItemUseStyleID.Swing;
        Item.useTime = 25;
        Item.useAnimation = 25;
        Item.knockBack = 5f;
        Item.UseSound = SoundID.Item1;
        Item.autoReuse = true;
        Item.rare = ItemRarityID.Orange;
        Item.value = Item.sellPrice(gold: 3);
    }

    public override void AddRecipes()
    {
        CreateRecipe().AddIngredient<BaihuEssence>(18).AddIngredient(ItemID.IceBlock, 50).AddTile(TileID.Anvils).Register();
    }
}

public sealed class BaihuEye : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Olho_Tigre_CONCEITO";

    public override void SetDefaults()
    {
        Item.width = 28;
        Item.height = 28;
        Item.accessory = true;
        Item.rare = ItemRarityID.Orange;
        Item.value = Item.sellPrice(gold: 2);
    }

    public override void UpdateAccessory(Player player, bool hideVisual)
    {
        player.GetDamage(DamageClass.Generic) += 0.04f;
        player.GetCritChance(DamageClass.Generic) += 2f;
    }
}

public sealed class BaihuTreasureBag : ModItem
{
    public override string Texture => "AlemDosCeusOrigem/Assets/Baihu/Treasure_Bag_CONCEITO";

    public override void SetDefaults()
    {
        Item.width = 32;
        Item.height = 32;
        Item.maxStack = 999;
        Item.rare = ItemRarityID.Expert;
        Item.expert = true;
    }

    public override bool CanRightClick() => true;

    public override void RightClick(Player player)
    {
        player.QuickSpawnItem(player.GetSource_OpenItem(Type), ModContent.ItemType<BaihuEssence>(), Main.rand.Next(12, 19));
        player.QuickSpawnItem(player.GetSource_OpenItem(Type), ModContent.ItemType<BaihuClaw>());
        player.QuickSpawnItem(player.GetSource_OpenItem(Type), ModContent.ItemType<BaihuBlade>());
        if (Main.rand.NextBool(4))
            player.QuickSpawnItem(player.GetSource_OpenItem(Type), ModContent.ItemType<BaihuEye>());
    }
}
